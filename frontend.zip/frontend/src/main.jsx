import { StrictMode } from "react";

import { createRoot } from "react-dom/client";

import { BrowserRouter } from "react-router-dom";

import { Toaster } from "react-hot-toast";

import App from "./App";

import "./index.css";

createRoot(
  document.getElementById("root")
).render(
  <StrictMode>
    <BrowserRouter>
      <App />
      <Toaster
        position="bottom-right"
        toastOptions={{
          duration: 4000,
          style: {
            background: "#111111",
            color: "#ffffff",
            border: "1px solid #27272a",
            borderRadius: "1rem",
          },
          error: {
            style: {
              background: "#0a0a0a",
              border: "1px solid #ef4444",
              color: "#fca5a5",
            },
          },
          success: {
            style: {
              background: "#0a0a0a",
              border: "1px solid #4ade80",
              color: "#86efac",
            },
          },
        }}
      />
    </BrowserRouter>
  </StrictMode>
);
