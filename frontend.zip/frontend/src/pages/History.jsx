import { useEffect, useState } from "react";

import MainLayout from "../components/layout/MainLayout";

import Loader from "../components/common/Loader";

import PageHeader from "../components/common/PageHeader";

import HistoryCard from "../components/history/HistoryCard";

import HistoryStats from "../components/history/HistoryStats";

import PerformanceGraph from "../components/history/PerformanceGraph";

import InterviewTimeline from "../components/history/InterviewTimeline";

import PerformanceSummary from "../components/history/PerformanceSummary";

import TopicPerformance from "../components/history/TopicPerformance";

import API from "../services/api";

function History() {

  const [history, setHistory] =
    useState(null);

  const [loading, setLoading] =
    useState(true);

  useEffect(() => {
    const loadHistory = async () => {
      try {
        const response =
          await API.get("/history");
        setHistory(response.data);
        setLoading(false);
      }
      catch (error) {
        console.log(error);
        setLoading(false);
      }
    };
    loadHistory();
  }, []);

  if (loading) {

    return <Loader />;
  }

  return (

    <MainLayout>

      <PageHeader
        title="Interview History"
        subtitle="Track your interview performance"
      />

      {/* STATS */}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">

        <HistoryStats
          title="Total Interviews"
          value={
            history.totalInterviews
          }
        />

        <HistoryStats
          title="Average Score"
          value={`${history.averageScore}%`}
        />

        <HistoryStats
          title="Best Score"
          value={`${history.bestScore}%`}
        />

      </div>

      {/* GRAPH */}

      <div className="mb-10">

        <PerformanceGraph
          data={history.chartData}
        />

      </div>

      {/* SUMMARY */}

      <div className="mb-10">

        <PerformanceSummary
          summary={
            history.summary
          }
        />

      </div>

      {/* TOPIC PERFORMANCE */}

      <div className="mb-10">

        <TopicPerformance
          topics={
            history.topicPerformance
          }
        />

      </div>

      {/* TIMELINE */}

      <div className="mb-10">

        <InterviewTimeline
          interviews={
            history.timeline
          }
        />

      </div>

      {/* HISTORY LIST */}

      <div className="space-y-6">

          {(history.interviews || []).map(
           (item, index) => (

            <HistoryCard
              key={index}
              item={item}
            />

          )
        )}

      </div>

    </MainLayout>
  );
}

export default History;