import { useState } from "react";

import {
	Eye,
	EyeOff,
	User,
	Mail,
	Lock,
	ArrowLeft,
} from "lucide-react";

import {
	Link,
	useNavigate,
} from "react-router-dom";

import API from "../services/api";

function Register() {

	const navigate = useNavigate();

	const [formData, setFormData] =
		useState({
			name: "",
			email: "",
			password: "",
		});

	const [showPassword, setShowPassword] =
		useState(false);

	const [loading, setLoading] =
		useState(false);

	const [error, setError] =
		useState("");

	const handleChange = (e) => {
		setFormData({
			...formData,
			[e.target.name]: e.target.value,
		});
		if (error) setError("");
	};

	const handleSubmit = async (e) => {
		e.preventDefault();
		if (!formData.name || !formData.email || !formData.password) {
			setError("Please fill in all fields");
			return;
		}
		if (formData.password.length < 6) {
			setError("Password must be at least 6 characters");
			return;
		}
		setLoading(true);
		setError("");
		try {
			await API.post("/auth/register", formData);
			navigate("/login");
		} catch (err) {
			setError(
				err.response?.data?.message ||
				"Registration failed. Please try again."
			);
		} finally {
			setLoading(false);
		}
	};

	return (
		<div className="min-h-screen bg-surface flex items-center justify-center p-4">

			<div className="w-full max-w-md">

				<Link
					to="/"
					className="flex items-center gap-2 text-muted hover:text-primary mb-6 transition-colors"
				>
					<ArrowLeft size={20} />
					<span className="text-sm">Back to Home</span>
				</Link>

				<div className="bg-surface-card border border-border rounded-3xl p-8 shadow-card">

					<div className="text-center mb-8">
						<h1 className="text-white text-3xl font-bold">
							Create Your Account
						</h1>
						<p className="text-muted mt-2 text-sm">
							Start your professional career journey
						</p>
					</div>

					{error && (
						<div className="bg-danger/10 border border-danger text-danger px-4 py-3 rounded-2xl mb-5 text-sm">
							{error}
						</div>
					)}

					<form
						onSubmit={handleSubmit}
						className="space-y-5"
					>

						<div>
							<label className="text-muted block text-sm mb-2">
								Full Name
							</label>
							<div className="relative">
								<User
									className="absolute left-4 top-4 text-muted"
									size={18}
								/>
								<input
									type="text"
									name="name"
									placeholder="John Doe"
									value={formData.name}
									onChange={handleChange}
									className="w-full bg-black border border-border-light rounded-2xl p-4 pl-12 text-white outline-none focus:border-accent transition-colors"
									required
								/>
							</div>
						</div>

						<div>
							<label className="text-muted block text-sm mb-2">
								Email Address
							</label>
							<div className="relative">
								<Mail
									className="absolute left-4 top-4 text-muted"
									size={18}
								/>
								<input
									type="email"
									name="email"
									placeholder="you@example.com"
									value={formData.email}
									onChange={handleChange}
									className="w-full bg-black border border-border-light rounded-2xl p-4 pl-12 text-white outline-none focus:border-accent transition-colors"
									required
								/>
							</div>
						</div>

						<div>
							<label className="text-muted block text-sm mb-2">
								Password
							</label>
							<div className="relative">
								<Lock
									className="absolute left-4 top-4 text-muted"
									size={18}
								/>
								<input
									type={showPassword ? "text" : "password"}
									name="password"
									placeholder="Enter your password"
									value={formData.password}
									onChange={handleChange}
									className="w-full bg-black border border-border-light rounded-2xl p-4 pl-12 pr-12 text-white outline-none focus:border-accent transition-colors"
									required
								/>
								<button
									type="button"
									onClick={() => setShowPassword(!showPassword)}
									className="absolute right-4 top-4 text-muted hover:text-primary transition-colors"
								>
									{showPassword ? (
										<EyeOff size={18} />
									) : (
										<Eye size={18} />
									)}
								</button>
							</div>
						</div>

						<button
							type="submit"
							disabled={loading}
							className={`w-full bg-primary text-black font-semibold p-4 rounded-2xl transition-colors flex items-center justify-center gap-2 ${
								loading
									? "opacity-50 cursor-not-allowed"
									: "hover:bg-primary-hover"
							}`}
						>
							{loading ? (
								<svg
									className="animate-spin h-5 w-5 text-black"
									xmlns="http://www.w3.org/2000/svg"
									fill="none"
									viewBox="0 0 24 24"
								>
									<circle
										className="opacity-25"
										cx="12"
										cy="12"
										r="10"
										stroke="currentColor"
										strokeWidth="4"
									></circle>
									<path
										className="opacity-75"
										fill="currentColor"
										d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0v1h2v2z"
									></path>
								</svg>
							) : null}
							{loading ? "Creating Account..." : "Create Account"}
						</button>

					</form>

					<div className="border-t border-border mt-6 pt-6 text-center">
						<p className="text-muted text-sm">
							Already have an account?
						</p>
						<Link
							to="/login"
							className="text-primary font-semibold mt-2 inline-block hover:text-primary-hover transition-colors"
						>
							Sign In
						</Link>
					</div>

				</div>

			</div>

		</div>
	);
}

export default Register;
