import { useEffect, useState } from "react";

import {
  Brain,
  Trophy,
  FileText,
} from "lucide-react";

import MainLayout from "../components/layout/MainLayout";

import PageHeader from "../components/common/PageHeader";

import Loader from "../components/common/Loader";

import StatCard from "../components/dashboard/StatCard";

import DashboardChart from "../components/dashboard/DashboardChart";

import SuggestionCard from "../components/dashboard/SuggestionCard";

import ActivityCard from "../components/dashboard/ActivityCard";

import RecentInterviewCard from "../components/dashboard/RecentInterviewCard";

import API from "../services/api";

function Dashboard() {

  const [dashboard, setDashboard] =
    useState(null);

  const [loading, setLoading] =
    useState(true);

  useEffect(() => {
    const loadDashboard = async () => {
      try {
        const response =
          await API.get("/dashboard");
        setDashboard(response.data);
        setLoading(false);
      }
      catch (error) {
        console.log(error);
        setLoading(false);
      }
    };
    loadDashboard();
  }, []);

  if (loading) {

    return <Loader />;
  }

  return (

    <MainLayout>

      <PageHeader
        title="Dashboard"
        subtitle="Track your AI interview performance"
      />

      {/* STATS */}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">

        <StatCard
          title="Total Interviews"
          value={dashboard.totalInterviews}
          subtitle="Completed interviews"
          icon={<Brain className="text-white" />}
        />

        <StatCard
          title="Average Score"
          value={`${dashboard.averageScore}%`}
          subtitle="Overall interview performance"
          icon={<Trophy className="text-white" />}
        />

        <StatCard
          title="Resume ATS"
          value={`${dashboard.resumeScore}/100`}
          subtitle="Resume analysis score"
          icon={<FileText className="text-white" />}
        />

      </div>

      {/* GRAPH */}

      <div className="mb-10">

        <DashboardChart
          data={dashboard.chartData}
        />

      </div>

      {/* AI SUGGESTION */}

      <div className="mb-10">

        <SuggestionCard
          suggestion={
            dashboard.aiSuggestion
          }
        />

      </div>

      {/* RECENT INTERVIEWS */}

      <div className="mb-10">

        <h2 className="text-white text-3xl font-bold mb-6">

          Recent Interviews

        </h2>

        <div className="space-y-5">

          {(dashboard.recentInterviews || []).map(
             (item, index) => (

              <RecentInterviewCard
                key={index}
                role={item.role}
                score={item.score}
                difficulty={
                  item.difficulty
                }
                date={item.date}
              />

            )
          )}

        </div>

      </div>

      {/* ACTIVITY */}

      <div>

        <h2 className="text-white text-3xl font-bold mb-6">

          Recent Activity

        </h2>

        <div className="space-y-5">

          {(dashboard.activities || []).map(
             (item, index) => (

              <ActivityCard
                key={index}
                title={item.title}
                time={item.time}
              />

            )
          )}

        </div>

      </div>

    </MainLayout>
  );
}

export default Dashboard;