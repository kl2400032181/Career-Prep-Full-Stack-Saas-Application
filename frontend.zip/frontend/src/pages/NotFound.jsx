import {
  Link,
} from "react-router-dom";

function NotFound() {

  return (

    <div className="min-h-screen bg-black flex flex-col justify-center items-center text-center p-5">

      <h1 className="text-white text-8xl font-black">

        404

      </h1>

      <p className="text-zinc-500 text-xl mt-5">

        Page Not Found

      </p>

      <Link
        to="/dashboard"
        className="bg-white text-black px-6 py-4 rounded-2xl font-semibold mt-8"
      >
        Back To Dashboard
      </Link>

    </div>
  );
}

export default NotFound;