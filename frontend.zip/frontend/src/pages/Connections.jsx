import { useEffect, useState } from "react";

import MainLayout from "../components/layout/MainLayout";

import PageHeader from "../components/common/PageHeader";

import Loader from "../components/common/Loader";

import SearchBar from "../components/common/SearchBar";

import ConnectionCard from "../components/profile/ConnectionCard";

import API from "../services/api";

function Connections() {

  const [users, setUsers] =
    useState([]);

  const [filteredUsers,
    setFilteredUsers] =
    useState([]);

  const [search,
    setSearch] =
    useState("");

  const [loading,
    setLoading] =
    useState(true);

  const handleConnect = async (email) => {
    try {
      await API.post("/connections/request", null, {
        params: { email },
      });
    } catch (error) {
      console.log(error);
      alert("Failed to send connection request");
    }
  };

  useEffect(() => {
    const loadConnections = async () => {
      try {
        const response =
          await API.get("/connections");
        setUsers(response.data);
        setFilteredUsers(response.data);
        setLoading(false);
      } catch (error) {
        console.log(error);
        setLoading(false);
      }
    };
    loadConnections();
  }, []);

  const handleSearch = (e) => {

    const value =
      e.target.value;

    setSearch(value);

    const filtered =
      users.filter((user) =>
        user.name
          .toLowerCase()
          .includes(
            value.toLowerCase()
          )
      );

    setFilteredUsers(filtered);
  };

  if (loading) {

    return <Loader />;
  }

  return (

    <MainLayout>

      <PageHeader
        title="Connections"
        subtitle="Build your professional network"
      />

      {/* SEARCH */}

      <div className="mb-10">

        <SearchBar
          value={search}
          onChange={handleSearch}
          placeholder="Search connections"
        />

      </div>

      {/* CONNECTIONS */}

      <div className="space-y-5">

          {filteredUsers.map(
            (user, index) => (
              <ConnectionCard
                key={index}
                user={user}
                onConnect={handleConnect}
              />
            )
          )}

      </div>

    </MainLayout>
  );
}

export default Connections;