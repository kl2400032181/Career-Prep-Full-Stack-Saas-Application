import { useState } from "react";

import MainLayout from "../components/layout/MainLayout";

import PageHeader from "../components/common/PageHeader";

import Loader from "../components/common/Loader";

import InterviewSetup from "../components/interview/InterviewSetup";

import InterviewProgress from "../components/interview/InterviewProgress";

import QuestionCard from "../components/interview/QuestionCard";

import AnswerInput from "../components/interview/AnswerInput";

import InterviewResult from "../components/interview/InterviewResult";

import API from "../services/api";

function Interview() {

  const [role, setRole] =
    useState("");

  const [difficulty, setDifficulty] =
    useState("Easy");

  const [questionCount, setQuestionCount] =
    useState(5);

  const [category, setCategory] =
    useState("React");

  const [loading, setLoading] =
    useState(false);

  const [questions, setQuestions] =
    useState([]);

  const [currentQuestion, setCurrentQuestion] =
    useState(0);

  const [answer, setAnswer] =
    useState("");

  const [result, setResult] =
    useState(null);

  const startInterview = async () => {

    try {

      setLoading(true);

      const response =
        await API.post(
          "/interview/start",
          {
            role,
            difficulty,
            questionCount: Number(questionCount),
            category,
          }
        );

      setQuestions(response.data);

      setLoading(false);

    }

    catch (error) {

      console.log(error);

      setLoading(false);
    }
  };

  const submitAnswer = async () => {

    try {

      setLoading(true);

      const response =
        await API.post(
          "/interview/submit",
          {
            question:
              questions[currentQuestion],

            answer,
          }
        );

      if (
        currentQuestion + 1 <
        questions.length
      ) {

        setCurrentQuestion(
          currentQuestion + 1
        );

        setAnswer("");

      }

      else {

        setResult(response.data);
      }

      setLoading(false);

    }

    catch (error) {

      console.log(error);

      setLoading(false);
    }
  };

  return (

    <MainLayout>

      <PageHeader
        title="AI Interview"
        subtitle="Practice professional AI interviews"
      />

      {!questions.length &&
        !result && (

          <InterviewSetup
            role={role}
            setRole={setRole}
            difficulty={difficulty}
            setDifficulty={
              setDifficulty
            }
            questionCount={
              questionCount
            }
            setQuestionCount={
              setQuestionCount
            }
            category={category}
            setCategory={setCategory}
            onStart={startInterview}
          />

        )}

      {loading && <Loader />}

      {questions.length > 0 &&
        !result && (

          <div className="space-y-8">

            <InterviewProgress
              currentQuestion={
                currentQuestion + 1
              }
              totalQuestions={
                questions.length
              }
            />

            <QuestionCard
              question={
                questions[
                  currentQuestion
                ]
              }
            />

            <AnswerInput
              answer={answer}
              setAnswer={setAnswer}
              onSubmit={submitAnswer}
            />

          </div>

        )}

      {result && (

        <InterviewResult
          result={result}
        />

      )}

    </MainLayout>
  );
}

export default Interview;