import { useEffect, useState } from "react";

import MainLayout from "../components/layout/MainLayout";

import Loader from "../components/common/Loader";

import PageHeader from "../components/common/PageHeader";

import ProfileHeader from "../components/profile/ProfileHeader";

import ProfileStats from "../components/profile/ProfileStats";

import SkillTag from "../components/profile/SkillTag";

import SocialLinks from "../components/profile/SocialLinks";

import ConnectionCard from "../components/profile/ConnectionCard";

import ExperienceCard from "../components/profile/ExperienceCard";

import ProjectCard from "../components/profile/ProjectCard";

import ProfileCompletion from "../components/profile/ProfileCompletion";

import EditProfileModal from "../components/profile/EditProfileModal";

import API from "../services/api";

function Profile() {

  const [profile, setProfile] =
    useState(null);

  const [open, setOpen] =
    useState(false);

  useEffect(() => {
    const loadProfile = async () => {
      try {
        const response =
          await API.get("/profile");
        setProfile(response.data);
      }
      catch (error) {
        console.log(error);
      }
    };
    loadProfile();
  }, []);

  const saveProfile = async () => {

    try {

      await API.put(
        "/profile/update",
        profile
      );

      setOpen(false);

    }

    catch (error) {

      console.log(error);
    }
  };

  if (!profile) {

    return <Loader />;
  }

  return (

    <MainLayout>

      <PageHeader
        title="My Profile"
        subtitle="Manage your professional profile"
      />

      {/* HEADER */}

      <div className="mb-10">

        <ProfileHeader
          profile={profile}
          onEdit={() =>
            setOpen(true)
          }
        />

      </div>

      {/* STATS */}

      <div className="mb-10">

        <ProfileStats
          followers={
            profile.followers
          }
          following={
            profile.following
          }
          interviews={
            profile.interviews
          }
          resumeScore={
            profile.resumeScore
          }
        />

      </div>

      {/* PROFILE COMPLETION */}

      <div className="mb-10">

        <ProfileCompletion
          percentage={
            profile.profileCompletion
          }
        />

      </div>

      {/* SKILLS */}

      <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6 mb-10">

        <h2 className="text-white text-3xl font-bold mb-6">

          Skills

        </h2>

        <div className="flex flex-wrap gap-4">

          {profile.skills?.map(
             (skill, index) => (

              <SkillTag
                key={index}
                skill={skill}
              />

            )
          )}

        </div>

      </div>

      {/* SOCIAL LINKS */}

      <div className="mb-10">

        <SocialLinks
          profile={profile}
        />

      </div>

      {/* EXPERIENCE */}

      <div className="mb-10">

        <h2 className="text-white text-3xl font-bold mb-6">

          Experience

        </h2>

        <div className="space-y-5">

          {(profile.experiences || []).map(
             (item, index) => (

              <ExperienceCard
                key={index}
                experience={item}
              />

            )
          )}

        </div>

      </div>

      {/* PROJECTS */}

      <div className="mb-10">

        <h2 className="text-white text-3xl font-bold mb-6">

          Projects

        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

          {(profile.projects || []).map(
             (item, index) => (

              <ProjectCard
                key={index}
                project={item}
              />

            )
          )}

        </div>

      </div>

      {/* CONNECTIONS */}

      <div>

        <h2 className="text-white text-3xl font-bold mb-6">

          Connections

        </h2>

        <div className="space-y-5">

          {(profile.connectionList || []).map(
            (item, index) => (

              <ConnectionCard
                key={index}
                user={item}
              />

            )
          )}

        </div>

      </div>

      {/* MODAL */}

      <EditProfileModal
        isOpen={open}
        onClose={() =>
          setOpen(false)
        }
        profile={profile}
        setProfile={setProfile}
        onSave={saveProfile}
      />

    </MainLayout>
  );
}

export default Profile;