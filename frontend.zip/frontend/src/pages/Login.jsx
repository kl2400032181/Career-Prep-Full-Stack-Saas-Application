import { useState } from "react";
import {
  Eye,
  EyeOff,
  Mail,
  Lock,
  ArrowLeft,
} from "lucide-react";
import {
  Link,
  useNavigate,
} from "react-router-dom";
import API from "../services/api";

function Login() {
  const navigate = useNavigate();

  const [formData, setFormData] =
    useState({
      email: "",
      password: "",
    });

  const [showPassword, setShowPassword] =
    useState(false);

  const [loading, setLoading] =
    useState(false);

  const [error, setError] =
    useState("");

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });

    if (error) setError("");
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (
      !formData.email ||
      !formData.password
    ) {
      setError(
        "Please fill in all fields"
      );
      return;
    }

    try {
      setLoading(true);

      const response =
        await API.post(
          "/auth/login",
          formData
        );

      const token =
        response.data.token;

      if (token) {
        localStorage.setItem(
          "token",
          token
        );

        navigate("/dashboard");
      }
    } catch (err) {
      setError(
        err.response?.data?.message ||
        "Invalid email or password"
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-black flex items-center justify-center px-4">

      <div className="w-full max-w-lg">

        <Link
          to="/"
          className="inline-flex items-center gap-2 text-zinc-400 hover:text-white transition mb-8"
        >
          <ArrowLeft size={18} />
          Back to Home
        </Link>

        <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-10">

          <div className="text-center mb-10">

            <h1 className="text-white text-4xl font-bold mb-3">
              Welcome Back
            </h1>

            <p className="text-zinc-500">
              Sign in to continue your career journey
            </p>

          </div>

          {error && (
            <div className="mb-6 bg-red-500/10 border border-red-500/30 text-red-400 px-4 py-3 rounded-xl">
              {error}
            </div>
          )}

          <form
            onSubmit={handleSubmit}
            className="space-y-6"
          >

            <div>

              <label className="block text-zinc-400 mb-2 text-sm">
                Email Address
              </label>

              <div className="relative">

                <Mail
                  size={18}
                  className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500"
                />

                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="you@example.com"
                  className="w-full h-14 bg-black border border-zinc-800 rounded-xl pl-12 pr-4 text-white outline-none focus:border-zinc-600"
                />

              </div>

            </div>

            <div>

              <label className="block text-zinc-400 mb-2 text-sm">
                Password
              </label>

              <div className="relative">

                <Lock
                  size={18}
                  className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500"
                />

                <input
                  type={
                    showPassword
                      ? "text"
                      : "password"
                  }
                  name="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="Enter password"
                  className="w-full h-14 bg-black border border-zinc-800 rounded-xl pl-12 pr-12 text-white outline-none focus:border-zinc-600"
                />

                <button
                  type="button"
                  onClick={() =>
                    setShowPassword(
                      !showPassword
                    )
                  }
                  className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-white"
                >
                  {showPassword ? (
                    <EyeOff size={18} />
                  ) : (
                    <Eye size={18} />
                  )}
                </button>

              </div>

            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full h-14 rounded-xl bg-white text-black font-semibold hover:bg-zinc-200 transition disabled:opacity-50"
            >
              {loading
                ? "Signing In..."
                : "Sign In"}
            </button>

          </form>

          <div className="border-t border-zinc-800 mt-8 pt-6 text-center">

            <p className="text-zinc-500">
              Don't have an account?
            </p>

            <Link
              to="/register"
              className="text-white font-medium mt-2 inline-block hover:text-zinc-300"
            >
              Create Account
            </Link>

          </div>

        </div>

      </div>

    </div>
  );
}

export default Login;