import { useState } from "react";

import MainLayout from "../components/layout/MainLayout";

import PageHeader from "../components/common/PageHeader";

import Loader from "../components/common/Loader";

import ResumeUpload from "../components/resume/ResumeUpload";

import ATSScoreCard from "../components/resume/ATSScoreCard";

import ResumeStrengthCard from "../components/resume/ResumeStrengthCard";

import MissingKeywords from "../components/resume/MissingKeywords";

import ResumeSuggestions from "../components/resume/ResumeSuggestions";

import SkillsExtracted from "../components/resume/SkillsExtracted";

import JobMatchCard from "../components/resume/JobMatchCard";

import API from "../services/api";

function ResumeAnalysis() {

  const [file, setFile] =
    useState(null);

  const [loading, setLoading] =
    useState(false);

  const [result, setResult] =
    useState(null);

  const handleUpload = async () => {

    if (!file) {
	alert("Please select a resume");
	return;
}

if (file.type !== "application/pdf") {
	alert("Only PDF files are allowed");
	return;
}
    try {

      setLoading(true);

      const formData =
        new FormData();

      formData.append(
        "file",
        file
      );

      const response =
        await API.post(
          "/resume/analyze",
          formData,
          {
            headers: {
              "Content-Type":
                "multipart/form-data",
            },
          }
        );

      setResult(response.data);

      setLoading(false);

    }

    catch (error) {

      console.log(error);

      setLoading(false);
    }
  };

  return (

    <MainLayout>

      <PageHeader
        title="Resume Analysis"
        subtitle="Get professional ATS resume insights"
      />

      {/* UPLOAD */}

      <div className="mb-10">

        <ResumeUpload
          fileName={file?.name}
          onChange={(e) =>
            setFile(
              e.target.files[0]
            )
          }
          onUpload={handleUpload}
        />

      </div>

      {loading && <Loader />}

      {result && (

        <div className="space-y-10">

          {/* TOP */}

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

            <ATSScoreCard
              score={
                result.atsScore
              }
            />

            <JobMatchCard
              role={result.jobRole}
              percentage={
                result.jobMatch
              }
            />

          </div>

          {/* STRENGTHS */}

          <ResumeStrengthCard
            strengths={
              result.strengths
            }
          />

          {/* KEYWORDS */}

          <MissingKeywords
            keywords={
              result.missingKeywords
            }
          />

          {/* SUGGESTIONS */}

          <ResumeSuggestions
            suggestions={
              result.suggestions
            }
          />

          {/* SKILLS */}

          <SkillsExtracted
            skills={
              result.skills
            }
          />

        </div>

      )}

    </MainLayout>
  );
}

export default ResumeAnalysis;