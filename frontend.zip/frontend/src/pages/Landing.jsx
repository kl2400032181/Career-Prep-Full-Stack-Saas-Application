import {
  Brain,
  FileText,
  Users,
  TrendingUp,
  ArrowRight,
} from "lucide-react";

import {
  Link,
  useNavigate,
} from "react-router-dom";

import { useEffect } from "react";

function Landing() {

  const navigate = useNavigate();

  useEffect(() => {

    if (localStorage.getItem("token")) {

      navigate("/dashboard");

    }

  }, [navigate]);

  const features = [

    {
      icon: <Brain size={24} />,
      title: "AI Mock Interviews",
      description:
        "Practice with AI-generated questions across multiple domains and receive instant feedback.",
    },

    {
      icon: <FileText size={24} />,
      title: "Resume ATS Scanner",
      description:
        "Upload resumes and receive ATS scores, keyword analysis, and AI recommendations.",
    },

    {
      icon: <TrendingUp size={24} />,
      title: "Performance Analytics",
      description:
        "Track interview scores, strengths, weaknesses, and improvement trends.",
    },

    {
      icon: <Users size={24} />,
      title: "Professional Networking",
      description:
        "Build connections and expand your professional network directly inside the platform.",
    },

  ];

  return (

    <div className="min-h-screen bg-surface text-white">

      {/* HEADER */}

      <header className="border-b border-border bg-surface-card sticky top-0 z-50">

        <div className="max-w-7xl mx-auto px-5 h-16 flex items-center justify-between">

          <div className="flex items-center gap-3">

            <Brain
              className="text-accent"
              size={30}
            />

            <h1 className="text-xl font-bold">
              AI Interview Prep
            </h1>

          </div>

          <div className="flex items-center gap-4">

            <Link
              to="/login"
              className="text-muted hover:text-white transition"
            >
              Sign In
            </Link>

            <Link
              to="/register"
              className="bg-accent hover:bg-accent-hover text-black font-semibold px-5 py-2 rounded-xl transition"
            >
              Get Started
            </Link>

          </div>

        </div>

      </header>

      {/* HERO */}

      <section className="min-h-[80vh] flex items-center">

        <div className="max-w-6xl mx-auto px-5 text-center">

          <h1 className="text-5xl md:text-7xl font-black leading-tight">

            Prepare Smarter

            <span className="text-accent">
              {" "}With AI
            </span>

          </h1>

          <p className="text-muted-light text-xl max-w-3xl mx-auto mt-8">

            Master interviews, optimize resumes,
            track progress, and grow your professional
            network using AI-powered career tools.

          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mt-10">

            <Link
              to="/register"
              className="bg-accent text-black px-8 py-4 rounded-2xl font-bold flex items-center justify-center gap-2 hover:bg-accent-hover transition"
            >

              Get Started Free

              <ArrowRight size={20} />

            </Link>

            <Link
              to="/login"
              className="border border-border px-8 py-4 rounded-2xl hover:border-accent transition"
            >

              Sign In

            </Link>

          </div>

        </div>

      </section>

      {/* FEATURES */}

      <section className="py-32 bg-surface-card">

        <div className="max-w-7xl mx-auto px-5">

          <div className="text-center mb-16">

            <h2 className="text-4xl font-bold">

              Everything You Need

            </h2>

            <p className="text-muted-light mt-4">

              One platform for interviews, resumes,
              analytics, and networking.

            </p>

          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">

            {features.map((feature, index) => (

              <div
                key={index}
                className="bg-surface border border-border rounded-3xl p-8 hover:border-accent/50 transition-all"
              >

                <div className="w-16 h-16 rounded-2xl bg-black border border-border flex items-center justify-center mb-6 text-accent">

                  {feature.icon}

                </div>

                <h3 className="text-xl font-bold mb-3">

                  {feature.title}

                </h3>

                <p className="text-muted-light leading-7">

                  {feature.description}

                </p>

              </div>

            ))}

          </div>

        </div>

      </section>

      {/* FOOTER */}

      <footer className="border-t border-border py-8">

        <div className="max-w-7xl mx-auto px-5 text-center">

          <p className="text-muted">

            © 2026 AI Interview Prep Platform.
            All rights reserved.

          </p>

        </div>

      </footer>

    </div>

  );
}

export default Landing;