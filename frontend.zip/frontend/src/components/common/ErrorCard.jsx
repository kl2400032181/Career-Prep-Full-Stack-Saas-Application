function ErrorCard({ message }) {

  return (

    <div className="bg-red-500/10 border border-red-500 rounded-2xl p-5">

      <p className="text-red-400">
        {message}
      </p>

    </div>
  );
}

export default ErrorCard;