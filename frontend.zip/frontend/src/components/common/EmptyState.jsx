function EmptyState({
  title,
  subtitle,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-12 text-center">

      <h2 className="text-white text-3xl font-bold mb-3">
        {title}
      </h2>

      <p className="text-zinc-500">
        {subtitle}
      </p>

    </div>
  );
}

export default EmptyState;