function SkeletonLoader() {

  return (

    <div className="animate-pulse space-y-5">

      <div className="h-12 bg-zinc-900 rounded-2xl"></div>

      <div className="h-40 bg-zinc-900 rounded-3xl"></div>

      <div className="h-40 bg-zinc-900 rounded-3xl"></div>

    </div>
  );
}

export default SkeletonLoader;