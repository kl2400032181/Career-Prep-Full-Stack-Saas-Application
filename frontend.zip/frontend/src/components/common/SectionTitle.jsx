function SectionTitle({
  title,
  subtitle,
}) {

  return (

    <div className="mb-6">

      <h2 className="text-white text-2xl font-bold">
        {title}
      </h2>

      {subtitle && (

        <p className="text-zinc-500 mt-2">
          {subtitle}
        </p>

      )}

    </div>
  );
}

export default SectionTitle;