function Modal({
  isOpen,
  onClose,
  children,
}) {

  if (!isOpen) return null;

  return (

    <div className="fixed inset-0 bg-black/70 flex justify-center items-center z-50 p-5">

      <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 w-full max-w-2xl relative">

        <button
          onClick={onClose}
          className="absolute right-5 top-5 text-zinc-500 hover:text-white"
        >
          ✕
        </button>

        {children}

      </div>

    </div>
  );
}

export default Modal;