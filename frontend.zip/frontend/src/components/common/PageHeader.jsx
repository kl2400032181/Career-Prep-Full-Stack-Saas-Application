function PageHeader({
  title,
  subtitle,
}) {
  return (
    <div className="mb-12">

      <h1 className="text-white text-4xl lg:text-5xl font-bold tracking-tight">
        {title}
      </h1>

      {subtitle && (
        <p className="text-zinc-500 mt-3 text-base lg:text-lg max-w-3xl">
          {subtitle}
        </p>
      )}

    </div>
  );
}

export default PageHeader;