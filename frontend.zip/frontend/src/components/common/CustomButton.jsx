function CustomButton({
  text,
  onClick,
  className = "",
  type = "button",
}) {

  return (

    <button
      type={type}
      onClick={onClick}
      className={`bg-white text-black px-6 py-3 rounded-2xl font-semibold hover:bg-zinc-300 transition-all duration-300 ${className}`}
    >
      {text}
    </button>
  );
}

export default CustomButton;