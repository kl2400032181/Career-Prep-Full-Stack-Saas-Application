import { motion } from "framer-motion";

function Loader() {

  return (

    <div className="flex justify-center items-center h-[300px]">

      <motion.div
        animate={{ rotate: 360 }}
        transition={{
          repeat: Infinity,
          duration: 1,
          ease: "linear",
        }}
        className="w-14 h-14 border-4 border-white border-t-transparent rounded-full"
      />

    </div>
  );
}

export default Loader;