import { Search } from "lucide-react";

function SearchBar({
  value,
  onChange,
  placeholder,
}) {

  return (

    <div className="relative">

      <Search
        className="absolute left-4 top-4 text-zinc-500"
        size={20}
      />

      <input
        type="text"
        value={value}
        onChange={onChange}
        placeholder={placeholder}
        className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl py-4 pl-12 pr-5 text-white outline-none"
      />

    </div>
  );
}

export default SearchBar;