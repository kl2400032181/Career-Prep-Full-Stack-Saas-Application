function AnalyticsCard({
  title,
  value,
  growth,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6">

      <p className="text-zinc-400 mb-3">
        {title}
      </p>

      <h1 className="text-white text-4xl font-bold">
        {value}
      </h1>

      <p className="text-green-400 mt-3">
        {growth}
      </p>

    </div>
  );
}

export default AnalyticsCard;