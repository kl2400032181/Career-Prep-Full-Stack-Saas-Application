import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";

function DashboardChart({
  data,
}) {
  return (
    <div className="bg-black border border-zinc-800 rounded-2xl p-6">

      <div className="mb-8">

        <h2 className="text-white text-2xl font-semibold">
          Performance Analytics
        </h2>

        <p className="text-zinc-500 mt-2">
          Track interview performance over time
        </p>

      </div>

      <div className="w-full h-[350px]">

        <ResponsiveContainer
          width="100%"
          height="100%"
        >

          <LineChart data={data}>

            <CartesianGrid
              stroke="#27272a"
              strokeDasharray="3 3"
            />

            <XAxis
              dataKey="name"
              stroke="#71717a"
              tickLine={false}
              axisLine={false}
            />

            <YAxis
              stroke="#71717a"
              tickLine={false}
              axisLine={false}
            />

            <Tooltip
              contentStyle={{
                backgroundColor: "#09090b",
                border: "1px solid #27272a",
                borderRadius: "12px",
                color: "#ffffff",
              }}
            />

            <Line
              type="monotone"
              dataKey="score"
              stroke="#ffffff"
              strokeWidth={3}
              dot={{
                r: 4,
                fill: "#ffffff",
              }}
              activeDot={{
                r: 6,
              }}
            />

          </LineChart>

        </ResponsiveContainer>

      </div>

    </div>
  );
}

export default DashboardChart;