function StatCard({
  title,
  value,
  subtitle,
  icon,
}) {
  return (
    <div className="bg-black border border-zinc-800 rounded-2xl p-6 hover:border-zinc-700 transition-all duration-300">

      <div className="flex justify-between items-start">

        <div>

          <p className="text-zinc-500 text-sm font-medium uppercase tracking-wide">
            {title}
          </p>

          <h2 className="text-white text-4xl font-bold mt-3">
            {value}
          </h2>

          <p className="text-zinc-500 text-sm mt-3">
            {subtitle}
          </p>

        </div>

        <div className="w-12 h-12 rounded-xl bg-zinc-900 border border-zinc-800 flex items-center justify-center">

          {icon}

        </div>

      </div>

    </div>
  );
}

export default StatCard;