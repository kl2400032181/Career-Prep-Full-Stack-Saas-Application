function ActivityCard({
  title,
  time,
}) {
  return (
    <div className="bg-black border border-zinc-800 rounded-2xl p-5 hover:border-zinc-700 transition-all">

      <div className="flex items-center justify-between">

        <div>

          <h2 className="text-white font-medium">
            {title}
          </h2>

          <p className="text-zinc-500 text-sm mt-1">
            {time}
          </p>

        </div>

        <div className="px-3 py-1 rounded-lg border border-zinc-700 text-zinc-300 text-xs">
          Completed
        </div>

      </div>

    </div>
  );
}

export default ActivityCard;