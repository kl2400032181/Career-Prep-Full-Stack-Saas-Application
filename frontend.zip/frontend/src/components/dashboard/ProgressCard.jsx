function ProgressCard({
  title,
  value,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6">

      <div className="flex justify-between items-center mb-4">

        <h2 className="text-white font-semibold">
          {title}
        </h2>

        <p className="text-white font-bold">
          {value}%
        </p>

      </div>

      <div className="w-full bg-zinc-800 rounded-full h-3">

        <div
          className="bg-white h-3 rounded-full"
          style={{
            width: `${value}%`,
          }}
        ></div>

      </div>

    </div>
  );
}

export default ProgressCard;