function RecentInterviewCard({
  role,
  score,
  difficulty,
  date,
}) {
  return (
    <div className="bg-black border border-zinc-800 rounded-2xl p-5 hover:border-zinc-700 transition-all">

      <div className="flex justify-between items-center">

        <div>

          <h2 className="text-white text-lg font-semibold">
            {role}
          </h2>

          <p className="text-zinc-500 text-sm mt-1">
            {difficulty} • {date}
          </p>

        </div>

        <div className="border border-zinc-700 px-4 py-2 rounded-xl text-white font-semibold">
          {score}%
        </div>

      </div>

    </div>
  );
}

export default RecentInterviewCard;