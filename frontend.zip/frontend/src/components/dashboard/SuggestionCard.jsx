function SuggestionCard({
  suggestion,
}) {
  return (
    <div className="bg-black border border-zinc-800 rounded-2xl p-6">

      <div className="mb-4">

        <h2 className="text-white text-2xl font-semibold">
          AI Suggestion
        </h2>

        <p className="text-zinc-500 text-sm mt-1">
          Personalized improvement recommendation
        </p>

      </div>

      <div className="border-l-2 border-zinc-700 pl-4">

        <p className="text-zinc-300 leading-7">
          {suggestion}
        </p>

      </div>

    </div>
  );
}

export default SuggestionCard;