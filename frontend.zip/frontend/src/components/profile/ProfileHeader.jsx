import {
  MapPin,
  GraduationCap,
} from "lucide-react";

function ProfileHeader({
  profile,
  onEdit,
}) {
  return (
    <div className="bg-black border border-zinc-800 rounded-2xl overflow-hidden">

      {/* COVER */}

      <div className="h-36 bg-zinc-900 border-b border-zinc-800" />

      {/* CONTENT */}

      <div className="px-8 pb-8">

        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between">

          {/* LEFT */}

          <div>

            <div className="-mt-12 mb-5">

              <img
                src={
                  profile?.profileImage ||
                  "https://i.pravatar.cc/150"
                }
                alt="profile"
                onError={(e) => {
                  e.target.src =
                    "https://i.pravatar.cc/150";
                }}
                className="w-24 h-24 rounded-full border-4 border-black object-cover"
              />

            </div>

            <h1 className="text-white text-3xl font-bold">
              {profile?.name || "User"}
            </h1>

            <p className="text-zinc-400 mt-2 text-lg">
              {profile?.headline ||
                "No professional headline"}
            </p>

            <div className="flex flex-wrap gap-5 mt-4 text-sm text-zinc-500">

              {profile?.college && (
                <div className="flex items-center gap-2">

                  <GraduationCap size={16} />

                  <span>{profile.college}</span>

                </div>
              )}

              {profile?.location && (
                <div className="flex items-center gap-2">

                  <MapPin size={16} />

                  <span>{profile.location}</span>

                </div>
              )}

            </div>

          </div>

          {/* RIGHT */}

          <div className="mt-6 lg:mt-0">

            <button
              onClick={onEdit}
              className="bg-white text-black px-5 py-2.5 rounded-xl font-medium hover:bg-zinc-200 transition"
            >
              Edit Profile
            </button>

          </div>

        </div>

        {/* BIO */}

        <div className="mt-8 border-t border-zinc-800 pt-6">

          <h3 className="text-white font-semibold mb-3">
            About
          </h3>

          <p className="text-zinc-400 leading-7">
            {profile?.bio ||
              "No bio available."}
          </p>

        </div>

      </div>

    </div>
  );
}

export default ProfileHeader;