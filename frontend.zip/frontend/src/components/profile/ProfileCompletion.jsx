function ProfileCompletion({
  percentage,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6">

      <div className="flex justify-between items-center mb-4">

        <h2 className="text-white text-xl font-bold">

          Profile Completion

        </h2>

        <p className="text-white font-bold">

          {percentage}%

        </p>

      </div>

      <div className="w-full bg-zinc-800 rounded-full h-4">

        <div
          className="bg-white h-4 rounded-full"
          style={{
            width: `${percentage}%`,
          }}
        ></div>

      </div>

    </div>
  );
}

export default ProfileCompletion;