function AchievementCard({
  achievement,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6">

      <h2 className="text-white text-xl font-bold">
        {achievement.title}
      </h2>

      <p className="text-zinc-500 mt-3">

        {achievement.description}

      </p>

    </div>
  );
}

export default AchievementCard;