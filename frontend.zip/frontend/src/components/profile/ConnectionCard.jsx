import { useState } from "react";

function ConnectionCard({
  user,
  onConnect,
}) {
  const [connecting, setConnecting] =
    useState(false);

  const [connected, setConnected] =
    useState(false);

  const handleConnect = async () => {

    if (!onConnect) return;

    if (connecting || connected) return;

    setConnecting(true);

    try {

      await onConnect(user.email);

      setConnected(true);

    } catch (error) {

      console.log(error);

    } finally {

      setConnecting(false);

    }
  };

  return (

    <div className="bg-black border border-zinc-800 rounded-2xl p-5 hover:border-zinc-700 transition-all">

      <div className="flex items-center justify-between">

        <div className="flex items-center gap-4">

          <img
            src={
              user?.profileImage ||
              "https://i.pravatar.cc/100"
            }
            alt={user?.name || "User"}
            className="w-14 h-14 rounded-full object-cover border border-zinc-800"
          />

          <div>

            <h2 className="text-white font-semibold">
              {user?.name || "Unknown User"}
            </h2>

            <p className="text-zinc-500 text-sm mt-1">
              {user?.headline || "No headline available"}
            </p>

          </div>

        </div>

        {onConnect && (

          <button
            onClick={handleConnect}
            disabled={connecting || connected}
            className={`px-4 py-2 rounded-xl font-medium transition ${
              connected
                ? "bg-zinc-800 text-white border border-zinc-700"
                : "bg-white text-black hover:bg-zinc-200"
            }`}
          >
            {connected
              ? "Connected"
              : connecting
              ? "Connecting..."
              : "Connect"}
          </button>

        )}

      </div>

    </div>
  );
}

export default ConnectionCard;