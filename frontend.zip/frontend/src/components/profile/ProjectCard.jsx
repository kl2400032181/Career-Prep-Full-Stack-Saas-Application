function ProjectCard({
  project,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6">

      <h2 className="text-white text-2xl font-bold">
        {project.title}
      </h2>

      <p className="text-zinc-400 mt-4 leading-8">

        {project.description}

      </p>

      <div className="flex gap-4 mt-6">

        <a
  href={project.github}
  target="_blank"
  rel="noreferrer"
>
          GitHub
        </a>

        <a
          href={project.live}
          target="_blank"
          className="bg-white text-black px-5 py-3 rounded-2xl"
        >
          Live Demo
        </a>

      </div>

    </div>
  );
}

export default ProjectCard;