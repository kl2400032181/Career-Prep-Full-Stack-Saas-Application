function UploadProfileImage({
  onChange,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6">

      <h2 className="text-white text-2xl font-bold mb-5">

        Upload Profile Image

      </h2>

      <input
        type="file"
        accept="image/*"
        onChange={onChange}
        className="text-white"
      />

    </div>
  );
}

export default UploadProfileImage;