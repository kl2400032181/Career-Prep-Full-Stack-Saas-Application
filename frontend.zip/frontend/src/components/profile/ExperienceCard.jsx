function ExperienceCard({
  experience,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6">

      <h2 className="text-white text-2xl font-bold">
        {experience.role}
      </h2>

      <p className="text-zinc-400 mt-2">
        {experience.company}
      </p>

      <p className="text-zinc-500 mt-2">
        {experience.duration}
      </p>

      <p className="text-zinc-400 mt-5 leading-8">

        {experience.description}

      </p>

    </div>
  );
}

export default ExperienceCard;