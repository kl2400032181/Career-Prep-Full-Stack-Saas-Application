function SkillTag({
  skill,
}) {

  return (

    <div className="bg-zinc-900 border border-zinc-800 px-5 py-3 rounded-2xl text-white hover:border-zinc-600 transition">

      {skill}

    </div>
  );
}

export default SkillTag;