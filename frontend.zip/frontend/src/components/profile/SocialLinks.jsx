import {
  Link,
  Globe,
} from "lucide-react";

function SocialLinks({
  profile,
}) {

  const links = [
    {
      name: "GitHub",
      url: profile.github,
      icon: <Link size={20} />,
    },
    {
      name: "LinkedIn",
      url: profile.linkedin,
      icon: <Link size={20} />,
    },
    {
      name: "LeetCode",
      url: profile.leetcode,
      icon: <Link size={20} />,
    },
    {
      name: "CodeChef",
      url: profile.codechef,
      icon: <Link size={20} />,
    },
    {
      name: "Portfolio",
      url: profile.portfolio,
      icon: <Globe size={20} />,
    },
  ];

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6">

      <h2 className="text-white text-2xl font-bold mb-6">
        Social Links
      </h2>

      <div className="flex flex-wrap gap-4">

        {links.map((item, index) => (

          <a
            key={index}
            href={item.url || "#"}
            target="_blank"
            rel="noreferrer"
            className={`px-5 py-3 rounded-2xl flex items-center gap-3 transition ${
              item.url
                ? "bg-zinc-900 hover:bg-zinc-800 text-white"
                : "bg-zinc-900 text-zinc-500 cursor-not-allowed pointer-events-none"
            }`}
          >

            {item.icon}

            {item.name}

          </a>

        ))}

      </div>

    </div>

  );
}

export default SocialLinks;