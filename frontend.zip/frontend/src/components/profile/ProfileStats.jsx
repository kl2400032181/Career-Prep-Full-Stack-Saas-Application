function ProfileStats({
  followers,
  following,
  interviews,
  resumeScore,
}) {

  const stats = [
    {
      label: "Followers",
      value: followers,
    },

    {
      label: "Following",
      value: following,
    },

    {
      label: "Interviews",
      value: interviews,
    },

    {
      label: "Resume ATS",
      value: resumeScore,
    },
  ];

  return (

    <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">

      {stats.map((item, index) => (

        <div
          key={index}
          className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6 text-center"
        >

          <h1 className="text-white text-4xl font-bold">
            {item.value}
          </h1>

          <p className="text-zinc-500 mt-3">
            {item.label}
          </p>

        </div>

      ))}

    </div>
  );
}

export default ProfileStats;