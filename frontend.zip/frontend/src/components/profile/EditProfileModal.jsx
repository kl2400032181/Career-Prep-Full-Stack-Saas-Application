import Modal from "../common/Modal";

function EditProfileModal({
	isOpen,
	onClose,
	profile,
	setProfile,
	onSave,
}) {

	const handleChange = (e) => {
		const { name, value } = e.target;
		setProfile({
			...profile,
			[name]: value,
		});
	};

	const handleSkillsChange = (e) => {
		setProfile({
			...profile,
			skills: e.target.value
				.split(",")
				.map((item) => item.trim())
				.filter(Boolean),
		});
	};

	const updateNested = (field, index, subField, value) => {
		const updated = [...(profile[field] || [])];
		if (updated[index]) {
			updated[index][subField] = value;
			setProfile({ ...profile, [field]: updated });
		}
	};

	const removeNested = (field, index) => {
		const updated = (profile[field] || []).filter((_, i) => i !== index);
		setProfile({ ...profile, [field]: updated });
	};

	const addNested = (field, template) => {
		setProfile({ ...profile, [field]: [...(profile[field] || []), template] });
	};

	return (
		<Modal
			isOpen={isOpen}
			onClose={onClose}
		>
			<h2 className="text-white text-3xl font-bold mb-8">
				Edit Profile
			</h2>

			<div className="space-y-5 max-h-[70vh] overflow-y-auto pr-2">

				<input
					type="text"
					name="profileImage"
					value={profile.profileImage || ""}
					onChange={handleChange}
					placeholder="Profile Picture URL"
					className="w-full bg-zinc-900 border border-zinc-700 p-4 rounded-2xl text-white outline-none"
				/>

				<input
					type="text"
					name="coverBanner"
					value={profile.coverBanner || ""}
					onChange={handleChange}
					placeholder="Cover Banner URL"
					className="w-full bg-zinc-900 border border-zinc-700 p-4 rounded-2xl text-white outline-none"
				/>

				<input
					type="text"
					name="name"
					value={profile.name}
					onChange={handleChange}
					placeholder="Name"
					className="w-full bg-zinc-900 border border-zinc-700 p-4 rounded-2xl text-white outline-none"
				/>

				<input
					type="text"
					name="headline"
					value={profile.headline || ""}
					onChange={handleChange}
					placeholder="Headline"
					className="w-full bg-zinc-900 border border-zinc-700 p-4 rounded-2xl text-white outline-none"
				/>

				<input
					type="text"
					name="location"
					value={profile.location || ""}
					onChange={handleChange}
					placeholder="Location"
					className="w-full bg-zinc-900 border border-zinc-700 p-4 rounded-2xl text-white outline-none"
				/>

				<input
					type="text"
					name="college"
					value={profile.college || ""}
					onChange={handleChange}
					placeholder="College"
					className="w-full bg-zinc-900 border border-zinc-700 p-4 rounded-2xl text-white outline-none"
				/>

				<input
					type="text"
					name="linkedin"
					value={profile.linkedin || ""}
					onChange={handleChange}
					placeholder="LinkedIn URL"
					className="w-full bg-zinc-900 border border-zinc-700 p-4 rounded-2xl text-white outline-none"
				/>

				<input
					type="text"
					name="github"
					value={profile.github || ""}
					onChange={handleChange}
					placeholder="GitHub URL"
					className="w-full bg-zinc-900 border border-zinc-700 p-4 rounded-2xl text-white outline-none"
				/>

				<input
					type="text"
					name="leetcode"
					value={profile.leetcode || ""}
					onChange={handleChange}
					placeholder="LeetCode URL"
					className="w-full bg-zinc-900 border border-zinc-700 p-4 rounded-2xl text-white outline-none"
				/>

				<input
					type="text"
					name="codechef"
					value={profile.codechef || ""}
					onChange={handleChange}
					placeholder="CodeChef URL"
					className="w-full bg-zinc-900 border border-zinc-700 p-4 rounded-2xl text-white outline-none"
				/>

				<input
					type="text"
					name="portfolio"
					value={profile.portfolio || ""}
					onChange={handleChange}
					placeholder="Portfolio URL"
					className="w-full bg-zinc-900 border border-zinc-700 p-4 rounded-2xl text-white outline-none"
				/>

				<input
					type="text"
					name="careerGoal"
					value={profile.careerGoal || ""}
					onChange={handleChange}
					placeholder="Career Goal"
					className="w-full bg-zinc-900 border border-zinc-700 p-4 rounded-2xl text-white outline-none"
				/>

				<input
					type="text"
					name="skills"
					value={Array.isArray(profile.skills) ? profile.skills.join(", ") : (profile.skills || "")}
					onChange={handleSkillsChange}
					placeholder="Skills, comma separated"
					className="w-full bg-zinc-900 border border-zinc-700 p-4 rounded-2xl text-white outline-none"
				/>

				<textarea
					rows="5"
					name="bio"
					value={profile.bio || ""}
					onChange={handleChange}
					placeholder="Bio"
					className="w-full bg-zinc-900 border border-zinc-700 p-4 rounded-2xl text-white outline-none"
				/>

				{/* EXPERIENCES */}

				<div className="border-t border-zinc-800 pt-5">
					<div className="flex justify-between items-center mb-3">
						<h3 className="text-white font-semibold">
							Experience ({profile.experiences?.length || 0})
						</h3>
						<button
							type="button"
							onClick={() => addNested("experiences", { role: "", company: "", duration: "", description: "" })}
							className="text-sm text-white bg-zinc-900 px-4 py-2 rounded-xl hover:bg-zinc-800 transition"
						>
							Add Experience
						</button>
					</div>

					{(profile.experiences || []).map((exp, index) => (
						<div key={index} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 mb-3 space-y-3">
							<input
								type="text"
								placeholder="Role"
								value={exp.role || ""}
								onChange={(e) => updateNested("experiences", index, "role", e.target.value)}
								className="w-full bg-zinc-800 border border-zinc-700 p-3 rounded-xl text-white outline-none"
							/>
							<input
								type="text"
								placeholder="Company"
								value={exp.company || ""}
								onChange={(e) => updateNested("experiences", index, "company", e.target.value)}
								className="w-full bg-zinc-800 border border-zinc-700 p-3 rounded-xl text-white outline-none"
							/>
							<input
								type="text"
								placeholder="Duration"
								value={exp.duration || ""}
								onChange={(e) => updateNested("experiences", index, "duration", e.target.value)}
								className="w-full bg-zinc-800 border border-zinc-700 p-3 rounded-xl text-white outline-none"
							/>
							<textarea
								rows="3"
								placeholder="Description"
								value={exp.description || ""}
								onChange={(e) => updateNested("experiences", index, "description", e.target.value)}
								className="w-full bg-zinc-800 border border-zinc-700 p-3 rounded-xl text-white outline-none"
							/>
							<button
								type="button"
								onClick={() => removeNested("experiences", index)}
								className="text-red-400 text-sm hover:text-red-300 transition"
							>
								Remove
							</button>
						</div>
					))}
				</div>

				{/* PROJECTS */}

				<div className="border-t border-zinc-800 pt-5">
					<div className="flex justify-between items-center mb-3">
						<h3 className="text-white font-semibold">
							Projects ({profile.projects?.length || 0})
						</h3>
						<button
							type="button"
							onClick={() => addNested("projects", { title: "", description: "", github: "", live: "" })}
							className="text-sm text-white bg-zinc-900 px-4 py-2 rounded-xl hover:bg-zinc-800 transition"
						>
							Add Project
						</button>
					</div>

					{(profile.projects || []).map((proj, index) => (
						<div key={index} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 mb-3 space-y-3">
							<input
								type="text"
								placeholder="Title"
								value={proj.title || ""}
								onChange={(e) => updateNested("projects", index, "title", e.target.value)}
								className="w-full bg-zinc-800 border border-zinc-700 p-3 rounded-xl text-white outline-none"
							/>
							<textarea
								rows="3"
								placeholder="Description"
								value={proj.description || ""}
								onChange={(e) => updateNested("projects", index, "description", e.target.value)}
								className="w-full bg-zinc-800 border border-zinc-700 p-3 rounded-xl text-white outline-none"
							/>
							<input
								type="text"
								placeholder="GitHub URL"
								value={proj.github || ""}
								onChange={(e) => updateNested("projects", index, "github", e.target.value)}
								className="w-full bg-zinc-800 border border-zinc-700 p-3 rounded-xl text-white outline-none"
							/>
							<input
								type="text"
								placeholder="Live Demo URL"
								value={proj.live || ""}
								onChange={(e) => updateNested("projects", index, "live", e.target.value)}
								className="w-full bg-zinc-800 border border-zinc-700 p-3 rounded-xl text-white outline-none"
							/>
							<button
								type="button"
								onClick={() => removeNested("projects", index)}
								className="text-red-400 text-sm hover:text-red-300 transition"
							>
								Remove
							</button>
						</div>
					))}
				</div>

				{/* ACHIEVEMENTS */}

				<div className="border-t border-zinc-800 pt-5">
					<div className="flex justify-between items-center mb-3">
						<h3 className="text-white font-semibold">
							Achievements ({profile.achievements?.length || 0})
						</h3>
						<button
							type="button"
							onClick={() => addNested("achievements", "")}
							className="text-sm text-white bg-zinc-900 px-4 py-2 rounded-xl hover:bg-zinc-800 transition"
						>
							Add Achievement
						</button>
					</div>

					{(profile.achievements || []).map((ach, index) => (
						<div key={index} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-4 mb-3 flex items-center gap-3">
							<input
								type="text"
								placeholder="Achievement description"
								value={ach || ""}
								onChange={(e) => {
									const updated = [...(profile.achievements || [])];
									updated[index] = e.target.value;
									setProfile({ ...profile, achievements: updated });
								}}
								className="flex-1 bg-zinc-800 border border-zinc-700 p-3 rounded-xl text-white outline-none"
							/>
							<button
								type="button"
								onClick={() => removeNested("achievements", index)}
								className="text-red-400 text-sm hover:text-red-300 transition"
							>
								Remove
							</button>
						</div>
					))}
				</div>

				<button
					onClick={onSave}
					className="bg-white text-black px-6 py-3 rounded-2xl font-semibold"
				>
					Save Changes
				</button>

			</div>

		</Modal>
	);
}

export default EditProfileModal;
