function ResumeStrengthCard({
  strengths,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6">

      <h2 className="text-white text-2xl font-bold mb-6">

        Resume Strengths

      </h2>

      <div className="space-y-4">

        {strengths.map(
          (item, index) => (

            <div
              key={index}
              className="bg-green-500/10 border border-green-500 rounded-2xl p-4 text-green-400"
            >

              ✅ {item}

            </div>

          )
        )}

      </div>

    </div>
  );
}

export default ResumeStrengthCard;