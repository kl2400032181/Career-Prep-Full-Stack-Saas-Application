function SkillsExtracted({
  skills,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6">

      <h2 className="text-white text-2xl font-bold mb-6">

        Extracted Skills

      </h2>

      <div className="flex flex-wrap gap-4">

        {skills.map(
          (skill, index) => (

            <div
              key={index}
              className="bg-zinc-900 border border-zinc-700 px-5 py-3 rounded-2xl"
            >

              {skill}

            </div>

          )
        )}

      </div>

    </div>
  );
}

export default SkillsExtracted;