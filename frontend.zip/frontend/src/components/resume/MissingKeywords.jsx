function MissingKeywords({
  keywords,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6">

      <h2 className="text-white text-2xl font-bold mb-6">

        Missing Keywords

      </h2>

      <div className="flex flex-wrap gap-4">

        {keywords.map(
          (item, index) => (

            <div
              key={index}
              className="bg-red-500/10 border border-red-500 text-red-400 px-5 py-3 rounded-2xl"
            >

              ❌ {item}

            </div>

          )
        )}

      </div>

    </div>
  );
}

export default MissingKeywords;