function ATSScoreCard({
  score,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8 text-center">

      <h2 className="text-zinc-400 text-xl mb-5">

        ATS Score

      </h2>

      <h1 className="text-white text-7xl font-black">

        {score}

      </h1>

      <p className="text-zinc-500 mt-4">
        Resume Performance Score
      </p>

    </div>
  );
}

export default ATSScoreCard;