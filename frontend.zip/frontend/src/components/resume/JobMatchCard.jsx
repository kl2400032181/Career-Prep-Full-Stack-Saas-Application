function JobMatchCard({
  role,
  percentage,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6 text-center">

      <h2 className="text-zinc-400 text-xl mb-5">

        Job Match

      </h2>

      <h1 className="text-white text-5xl font-bold">

        {percentage}%

      </h1>

      <p className="text-zinc-500 mt-4">

        Match For {role}

      </p>

    </div>
  );
}

export default JobMatchCard;