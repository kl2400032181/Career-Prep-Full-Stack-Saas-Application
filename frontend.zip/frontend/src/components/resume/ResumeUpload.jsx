function ResumeUpload({
  onChange,
  onUpload,
  fileName,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8">

      <h2 className="text-white text-3xl font-bold mb-8">

        Upload Resume

      </h2>

      <input
        type="file"
        accept=".pdf"
        onChange={onChange}
        className="text-white"
      />

      {fileName && (

        <p className="text-zinc-500 mt-4">

          Selected:
          {" "}
          {fileName}

        </p>

      )}

      <button
	onClick={onUpload}
	className="bg-white text-black px-6 py-4 rounded-2xl font-semibold mt-6 hover:bg-zinc-300 transition"
	disabled={!fileName}
>

	Analyze Resume

</button>

    </div>
  );
}

export default ResumeUpload;