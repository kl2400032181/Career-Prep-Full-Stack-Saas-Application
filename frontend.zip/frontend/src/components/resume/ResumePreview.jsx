function ResumePreview({
  fileUrl,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl overflow-hidden h-[700px]">

      <iframe
        src={fileUrl}
        title="Resume Preview"
        className="w-full h-full"
      ></iframe>

    </div>
  );
}

export default ResumePreview;