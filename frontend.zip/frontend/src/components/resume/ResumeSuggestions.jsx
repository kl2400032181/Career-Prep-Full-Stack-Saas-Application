function ResumeSuggestions({
  suggestions,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6">

      <h2 className="text-white text-2xl font-bold mb-6">

        AI Suggestions

      </h2>

      <div className="space-y-4">

        {suggestions.map(
          (item, index) => (

            <div
              key={index}
              className="bg-yellow-500/10 border border-yellow-500 rounded-2xl p-4 text-yellow-400"
            >

              ⚠ {item}

            </div>

          )
        )}

      </div>

    </div>
  );
}

export default ResumeSuggestions;