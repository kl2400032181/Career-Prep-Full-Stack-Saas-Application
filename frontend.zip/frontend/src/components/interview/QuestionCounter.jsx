function QuestionCounter({
  questionCount,
  setQuestionCount,
}) {

  return (

    <div>

      <label className="text-zinc-400 block mb-3">

        Number Of Questions

      </label>

      <select
        value={questionCount}
        onChange={(e) =>
          setQuestionCount(
            Number(e.target.value)
          )
        }
        className="w-full bg-zinc-900 border border-zinc-700 rounded-2xl p-4 text-white outline-none"
      >

        <option value="3">
          3 Questions
        </option>

        <option value="5">
          5 Questions
        </option>

        <option value="8">
          8 Questions
        </option>

        <option value="10">
          10 Questions
        </option>

      </select>

    </div>
  );
}

export default QuestionCounter;