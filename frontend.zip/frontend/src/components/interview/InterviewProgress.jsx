function InterviewProgress({
  currentQuestion = 0,
  totalQuestions = 0,
}) {

  const percentage =
    totalQuestions > 0
      ? (currentQuestion / totalQuestions) * 100
      : 0;

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6">

      <div className="flex justify-between items-center mb-4">

        <h2 className="text-white text-xl font-bold">
          Interview Progress
        </h2>

        <p className="text-white">
          {currentQuestion}/{totalQuestions}
        </p>

      </div>

      <div className="w-full bg-zinc-800 rounded-full h-4">

        <div
          className="bg-white h-4 rounded-full transition-all duration-500"
          style={{
            width: `${percentage}%`,
          }}
        ></div>

      </div>

    </div>

  );
}

export default InterviewProgress;