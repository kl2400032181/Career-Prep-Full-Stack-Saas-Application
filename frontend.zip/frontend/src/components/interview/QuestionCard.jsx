function QuestionCard({
  question = "",
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8">

      <h2 className="text-white text-3xl font-bold mb-6">
        Interview Question
      </h2>

      <p className="text-zinc-300 leading-9 text-lg">
        {question}
      </p>

    </div>

  );
}

export default QuestionCard;