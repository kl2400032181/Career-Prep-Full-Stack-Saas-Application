function DifficultySelector({
  difficulty,
  setDifficulty,
}) {

  return (

    <div>

      <label className="text-zinc-400 block mb-3">

        Difficulty Level

      </label>

      <select
        value={difficulty}
        onChange={(e) =>
          setDifficulty(e.target.value)
        }
        className="w-full bg-zinc-900 border border-zinc-700 rounded-2xl p-4 text-white outline-none"
      >

        <option value="Easy">
          Easy
        </option>

        <option value="Medium">
          Medium
        </option>

        <option value="Hard">
          Hard
        </option>

      </select>

    </div>
  );
}

export default DifficultySelector;