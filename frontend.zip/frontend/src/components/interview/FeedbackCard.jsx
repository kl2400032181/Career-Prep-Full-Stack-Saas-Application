function FeedbackCard({
  feedback = "No feedback available.",
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6">

      <h2 className="text-white text-2xl font-bold mb-5">
        AI Feedback
      </h2>

      <p className="text-zinc-400 leading-8">
        {feedback}
      </p>

    </div>

  );
}

export default FeedbackCard;