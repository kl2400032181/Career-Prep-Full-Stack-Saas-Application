import ScoreCard from "./ScoreCard";

import FeedbackCard from "./FeedbackCard";

import InterviewSummary from "./InterviewSummary";

function InterviewResult({
  result,
}) {

  return (

    <div className="space-y-8">

      {/* SCORES */}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">

        <ScoreCard
          title="Overall"
          score={result.overallScore}
        />

        <ScoreCard
          title="Technical"
          score={result.technicalScore}
        />

        <ScoreCard
          title="Communication"
          score={result.communicationScore}
        />

        <ScoreCard
          title="Confidence"
          score={result.confidenceScore}
        />

      </div>

      {/* FEEDBACK */}

      <FeedbackCard
        feedback={result.feedback}
      />

      {/* SUMMARY */}

      <InterviewSummary
        summary={result.summary}
      />

    </div>
  );
}

export default InterviewResult;