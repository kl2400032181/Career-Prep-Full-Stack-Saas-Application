function CategorySelector({
  category,
  setCategory,
}) {

  const categories = [

    "Java",

    "Python",

    "JavaScript",

    "React",

    "Spring Boot",

    "Node.js",

    "DSA",

    "DBMS",

    "Operating Systems",

    "Computer Networks",

    "OOPS",

    "System Design",

    "Machine Learning",

    "Cloud",

    "DevOps",

    "HR Interview",
  ];

  return (

    <div>

      <label className="text-zinc-400 block mb-3">

        Interview Category

      </label>

      <select
        value={category}
        onChange={(e) =>
          setCategory(e.target.value)
        }
        className="w-full bg-zinc-900 border border-zinc-700 rounded-2xl p-4 text-white outline-none"
      >

        {categories.map((item) => (

          <option
            key={item}
            value={item}
          >
            {item}
          </option>

        ))}

      </select>

    </div>
  );
}

export default CategorySelector;