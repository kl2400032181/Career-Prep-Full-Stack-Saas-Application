function InterviewSummary({
  summary = "No summary available.",
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6">

      <h2 className="text-white text-2xl font-bold mb-5">
        Interview Summary
      </h2>

      <p className="text-zinc-400 leading-8">
        {summary}
      </p>

    </div>

  );
}

export default InterviewSummary;