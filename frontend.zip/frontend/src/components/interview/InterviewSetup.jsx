import DifficultySelector from "./DifficultySelector";

import CategorySelector from "./CategorySelector";

import QuestionCounter from "./QuestionCounter";

function InterviewSetup({
	role,
	setRole,
	difficulty,
	setDifficulty,
	questionCount,
	setQuestionCount,
	category,
	setCategory,
	onStart,
}) {

	return (

		<div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6 lg:p-8">

			<div className="mb-8">

				<h2 className="text-white text-3xl font-bold mb-3">
					Interview Setup
				</h2>

				<p className="text-zinc-500 leading-7 max-w-2xl">
					Configure the role, category, and difficulty before starting your AI mock interview.
				</p>

			</div>

			<div className="grid grid-cols-1 lg:grid-cols-2 gap-6">

				<div>

					<label className="text-zinc-400 block mb-3">
						Role Title
					</label>

					<input
						type="text"
						value={role}
						onChange={(e) => setRole(e.target.value)}
						placeholder="e.g. Frontend Developer"
						className="w-full bg-zinc-900 border border-zinc-700 rounded-2xl p-4 text-white outline-none"
					/>

				</div>

				<DifficultySelector
					difficulty={difficulty}
					setDifficulty={setDifficulty}
				/>

				<CategorySelector
					category={category}
					setCategory={setCategory}
				/>

				<QuestionCounter
					questionCount={questionCount}
					setQuestionCount={setQuestionCount}
				/>

			</div>

			<div className="mt-8 flex justify-end">

				<button
					type="button"
					onClick={onStart}
					className="bg-white text-black font-semibold px-6 py-3 rounded-2xl hover:bg-zinc-300 transition"
				>
					Start Interview
				</button>

			</div>

		</div>
	);
}

export default InterviewSetup;
