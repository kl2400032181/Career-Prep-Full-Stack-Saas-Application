function AnswerInput({
  answer,
  setAnswer,
  onSubmit,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8">

      <h2 className="text-white text-2xl font-bold mb-6">

        Your Answer

      </h2>

      <textarea
        rows="8"
        value={answer}
        onChange={(e) =>
          setAnswer(e.target.value)
        }
        placeholder="Write your answer here..."
        className="w-full bg-zinc-900 border border-zinc-700 rounded-2xl p-5 text-white outline-none"
      />

      <button
        onClick={onSubmit}
        className="bg-white text-black px-6 py-4 rounded-2xl font-semibold mt-6 hover:bg-zinc-300 transition"
      >
        Submit Answer
      </button>

    </div>
  );
}

export default AnswerInput;