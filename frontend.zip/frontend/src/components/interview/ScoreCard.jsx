function ScoreCard({
  title,
  score = 0,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6 text-center">

      <h2 className="text-zinc-400 mb-4">
        {title}
      </h2>

      <h1 className="text-white text-5xl font-bold">
        {score}%
      </h1>

    </div>

  );
}

export default ScoreCard;