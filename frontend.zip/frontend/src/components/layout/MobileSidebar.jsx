import {
  LayoutDashboard,
  User,
  Brain,
  History,
  FileText,
  Users,
  X,
} from "lucide-react";

import { Link, useLocation } from "react-router-dom";

function MobileSidebar({
  isOpen,
  onClose,
}) {

  const location = useLocation();

  const menus = [

    {
      name: "Dashboard",
      path: "/dashboard",
      icon: <LayoutDashboard size={20} />,
    },

    {
      name: "Profile",
      path: "/profile",
      icon: <User size={20} />,
    },

    {
      name: "AI Interview",
      path: "/interview",
      icon: <Brain size={20} />,
    },

    {
      name: "Interview History",
      path: "/history",
      icon: <History size={20} />,
    },

    {
      name: "Resume Analysis",
      path: "/resume-analysis",
      icon: <FileText size={20} />,
    },

    {
      name: "Connections",
      path: "/connections",
      icon: <Users size={20} />,
    },
  ];

  if (!isOpen) return null;

  return (

    <div className="fixed inset-0 z-50 bg-black/80 lg:hidden">

      <div className="w-[280px] bg-surface-card border-r border-border min-h-screen p-6">

        {/* TOP */}

        <div className="flex justify-between items-center mb-12">

          <div className="flex items-center gap-3">

            <Brain
              className="text-accent"
              size={32}
            />

            <div>

              <h1 className="text-white text-3xl font-black">
                AI Prep
              </h1>

              <p className="text-muted mt-1 text-sm">
                Career Platform
              </p>

            </div>

          </div>

          <button
            onClick={onClose}
            className="text-muted hover:text-primary transition-colors"
          >

            <X size={24} />

          </button>

        </div>

        {/* MENUS */}

        <div className="flex flex-col gap-4">

          {menus.map((menu) => (

            <Link
              key={menu.path}
              to={menu.path}
              onClick={onClose}
              className={`flex items-center gap-4 p-4 rounded-2xl transition-all duration-300 ${
                location.pathname === menu.path
                  ? "bg-accent text-black"
                  : "text-primary hover:bg-black hover:border-accent/50 border border-transparent"
              }`}
            >

              {menu.icon}

              <span className="font-medium">
                {menu.name}
              </span>

            </Link>

          ))}

        </div>

      </div>

    </div>
  );
}

export default MobileSidebar;