import {
  Bell,
  Search,
  Menu,
  User,
} from "lucide-react";

import {
  useNavigate,
  Link,
} from "react-router-dom";

import { useEffect, useState } from "react";

import API from "../../services/api";

function Navbar({
  onMenuClick,
}) {

  const navigate = useNavigate();

  const [profile, setProfile] =
    useState(null);

  useEffect(() => {
    const loadProfile = async () => {
      try {
        const response =
          await API.get("/profile");

        setProfile(response.data);

      } catch (error) {
        console.log(error);
      }
    };

    loadProfile();
  }, []);

  const handleLogout = () => {

    localStorage.removeItem("token");

    navigate("/login");
  };

  return (

    <div className="sticky top-0 z-40 bg-black border-b border-zinc-800 px-6 py-4 flex justify-between items-center">

      <div className="flex items-center gap-4">

        <button
          onClick={onMenuClick}
          className="lg:hidden p-2 rounded-lg hover:bg-zinc-900"
        >
          <Menu
            className="text-white"
            size={20}
          />
        </button>

        <Link to="/dashboard">
          <h1 className="text-white text-xl font-semibold">
            AI Interview Prep
          </h1>
        </Link>

      </div>

      <div className="flex items-center gap-4">

        <div className="hidden md:flex items-center bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2">

          <Search
            size={18}
            className="text-zinc-500"
          />

          <input
            type="text"
            placeholder="Search"
            className="bg-transparent ml-3 text-white outline-none"
          />

        </div>

        <button className="p-2 rounded-lg hover:bg-zinc-900">

          <Bell
            size={20}
            className="text-zinc-400"
          />

        </button>

        <div className="w-9 h-9 rounded-full bg-zinc-800 flex items-center justify-center text-white">

          {profile?.name?.charAt(0) || (
            <User size={18} />
          )}

        </div>

        <button
          onClick={handleLogout}
          className="px-4 py-2 rounded-xl bg-white text-black font-medium hover:bg-zinc-200"
        >
          Logout
        </button>

      </div>

    </div>
  );
}

export default Navbar;