import {
  LayoutDashboard,
  User,
  Brain,
  History,
  FileText,
  Users,
} from "lucide-react";

import { Link, useLocation } from "react-router-dom";

function Sidebar() {
  const location = useLocation();

  const menus = [
    {
      name: "Dashboard",
      path: "/dashboard",
      icon: <LayoutDashboard size={20} />,
    },
    {
      name: "Profile",
      path: "/profile",
      icon: <User size={20} />,
    },
    {
      name: "AI Interview",
      path: "/interview",
      icon: <Brain size={20} />,
    },
    {
      name: "Interview History",
      path: "/history",
      icon: <History size={20} />,
    },
    {
      name: "Resume Analysis",
      path: "/resume-analysis",
      icon: <FileText size={20} />,
    },
    {
      name: "Connections",
      path: "/connections",
      icon: <Users size={20} />,
    },
  ];

  return (
    <div className="w-[280px] bg-black border-r border-zinc-800 min-h-screen p-6 hidden lg:block">

      <div className="mb-12">

        <h1 className="text-white text-3xl font-bold">
          AI Interview Prep
        </h1>

        <p className="text-zinc-500 mt-2 text-sm">
          Career Intelligence Platform
        </p>

      </div>

      <div className="flex flex-col gap-3">

        {menus.map((menu) => (

          <Link
            key={menu.path}
            to={menu.path}
            className={`flex items-center gap-4 px-4 py-3 rounded-xl transition-all ${
              location.pathname === menu.path
                ? "bg-white text-black"
                : "text-zinc-400 hover:text-white hover:bg-zinc-900"
            }`}
          >
            {menu.icon}

            <span className="font-medium">
              {menu.name}
            </span>

          </Link>

        ))}

      </div>

    </div>
  );
}

export default Sidebar;