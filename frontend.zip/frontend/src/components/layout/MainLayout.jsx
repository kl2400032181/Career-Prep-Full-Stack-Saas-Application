import { useState } from "react";

import Sidebar from "./Sidebar";

import Navbar from "./Navbar";

import MobileSidebar from "./MobileSidebar";

function MainLayout({
  children,
}) {

  const [isOpen, setIsOpen] =
    useState(false);

  return (

    <div className="flex bg-black min-h-screen">

      {/* DESKTOP SIDEBAR */}

      <Sidebar />

      {/* MOBILE SIDEBAR */}

      <MobileSidebar
        isOpen={isOpen}
        onClose={() =>
          setIsOpen(false)
        }
      />

      {/* MAIN */}

      <div className="flex-1">

        <Navbar
          onMenuClick={() =>
            setIsOpen(true)
          }
        />

        <div className="p-5 lg:p-8">

          {children}

        </div>

      </div>

    </div>
  );
}

export default MainLayout;