function InterviewTimeline({
  interviews,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6">

      <h2 className="text-white text-2xl font-bold mb-8">

        Interview Timeline

      </h2>

      <div className="space-y-6">

        {interviews.map(
          (item, index) => (

            <div
              key={index}
              className="flex items-start gap-5"
            >

              {/* DOT */}

              <div className="w-4 h-4 rounded-full bg-white mt-2"></div>

              {/* CONTENT */}

              <div>

                <h2 className="text-white font-semibold">

                  {item.role}

                </h2>

                <p className="text-zinc-500 mt-1">

                  {item.date}

                </p>

              </div>

            </div>

          )
        )}

      </div>

    </div>
  );
}

export default InterviewTimeline;