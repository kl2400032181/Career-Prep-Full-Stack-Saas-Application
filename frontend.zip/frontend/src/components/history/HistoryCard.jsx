function HistoryCard({
  item,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6">

      <div className="flex flex-col lg:flex-row lg:justify-between lg:items-center gap-5">

        {/* LEFT */}

        <div>

          <h2 className="text-white text-2xl font-bold">

            {item.role}

          </h2>

          <p className="text-zinc-500 mt-2">

            {item.category}
            {" • "}
            {item.difficulty}

          </p>

          <p className="text-zinc-600 mt-2 text-sm">

            {item.date}

          </p>

        </div>

        {/* SCORE */}

        <div className="bg-white text-black px-6 py-4 rounded-2xl font-bold text-xl">

          {item.score}%

        </div>

      </div>

      {/* FEEDBACK */}

      <div className="mt-6">

        <h3 className="text-zinc-400 mb-3">

          AI Feedback

        </h3>

        <p className="text-zinc-300 leading-8">

          {item.feedback}

        </p>

      </div>

    </div>
  );
}

export default HistoryCard;