function HistoryStats({
  title,
  value,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6 text-center">

      <h1 className="text-white text-5xl font-bold">

        {value}

      </h1>

      <p className="text-zinc-500 mt-4">

        {title}

      </p>

    </div>
  );
}

export default HistoryStats;