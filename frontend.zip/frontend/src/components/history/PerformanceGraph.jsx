import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";

function PerformanceGraph({
  data,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-8">

      <div className="mb-8">

        <h2 className="text-white text-3xl font-bold">

          Performance Graph

        </h2>

        <p className="text-zinc-500 mt-2">

          Interview score growth tracking

        </p>

      </div>

      <div className="w-full min-w-0 min-h-[350px] h-[350px]">

        <ResponsiveContainer width="100%" height={350}>

          <LineChart data={data}>

            <CartesianGrid stroke="#27272a" />

            <XAxis
              dataKey="name"
              stroke="#71717a"
            />

            <YAxis stroke="#71717a" />

            <Tooltip />

            <Line
              type="monotone"
              dataKey="score"
              stroke="#ffffff"
              strokeWidth={4}
            />

          </LineChart>

        </ResponsiveContainer>

      </div>

    </div>
  );
}

export default PerformanceGraph;