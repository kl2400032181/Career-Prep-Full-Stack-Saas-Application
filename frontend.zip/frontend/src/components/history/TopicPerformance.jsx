function TopicPerformance({
  topics,
}) {

  return (

    <div className="bg-zinc-950 border border-zinc-800 rounded-3xl p-6">

      <h2 className="text-white text-2xl font-bold mb-8">

        Topic Performance

      </h2>

      <div className="space-y-6">

        {topics.map(
          (item, index) => (

            <div key={index}>

              {/* TOP */}

              <div className="flex justify-between mb-3">

                <h3 className="text-white">

                  {item.topic}

                </h3>

                <p className="text-zinc-400">

                  {item.score}%

                </p>

              </div>

              {/* BAR */}

              <div className="w-full bg-zinc-800 rounded-full h-3">

                <div
                  className="bg-white h-3 rounded-full"
                  style={{
                    width: `${item.score}%`,
                  }}
                ></div>

              </div>

            </div>

          )
        )}

      </div>

    </div>
  );
}

export default TopicPerformance;