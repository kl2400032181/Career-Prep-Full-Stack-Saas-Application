import axios from "axios";
import { toast } from "react-hot-toast";

const API = axios.create({
  baseURL:
    import.meta.env.VITE_API_BASE_URL ||
    "http://localhost:8080/api",

  headers: {
    "Content-Type": "application/json",
  },

  timeout: 15000,
});

API.interceptors.request.use(
  (config) => {

    const token =
      localStorage.getItem("token");

    if (token) {
      config.headers.Authorization =
        `Bearer ${token}`;
    }

    return config;
  },

  (error) => Promise.reject(error)
);

API.interceptors.response.use(
  (response) => response,

  (error) => {

    if (error.response?.status === 401) {

      localStorage.removeItem("token");

      window.location.href = "/login";
    }

    else if (error.response?.status >= 400) {

      const message =
        error.response?.data?.message ||
        error.response?.data?.error ||
        "Something went wrong";

      toast.error(message);
    }

    return Promise.reject(error);
  }
);

export default API;