/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx,ts,tsx}",
  ],

  theme: {
    extend: {

      colors: {
        primary: "#ffffff",
        "primary-hover": "#f4f4f5",

        surface: "#0a0a0a",
        "surface-light": "#111111",
        "surface-card": "#111111",

        border: "#27272a",
        "border-light": "#3f3f46",

        muted: "#71717a",
        "muted-light": "#a1a1aa",

        accent: "#facc15",
        "accent-hover": "#eacb00",

        success: "#4ade80",
        danger: "#f87171",
        info: "#38bdf8",
      },

      borderRadius: {
        card: "1.5rem",
        input: "1rem",
      },

      boxShadow: {
        card:
          "0 4px 6px -1px rgba(0,0,0,0.3), 0 2px 4px -2px rgba(0,0,0,0.3)",

        "card-hover":
          "0 10px 15px -3px rgba(0,0,0,0.4), 0 4px 6px -4px rgba(0,0,0,0.4)",
      },

      fontFamily: {
        inter: [
          "Inter",
          "system-ui",
          "sans-serif",
        ],
      },
    },
  },

  plugins: [],
};