package com.airesume.backend.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;

import java.security.Key;
import java.util.Date;

public class JwtUtil {

    private static final String SECRET =
                        "THIS_IS_MY_SUPER_SECRET_KEY_FOR_AI_PLATFORM_1234567890";

    private static final Key KEY =
            Keys.hmacShaKeyFor(
                    SECRET.getBytes()
            );

    public static String generateToken(
            String email
    ) {

        return Jwts.builder()

                .setSubject(email)

                .setIssuedAt(new Date())

                .setExpiration(
                        new Date(
                                System.currentTimeMillis()
                                        + 86400000
                        )
                )

                .signWith(
                        KEY,
                        SignatureAlgorithm.HS256
                )

                .compact();
    }

    public static String extractEmail(
            String token
    ) {

        return Jwts.parserBuilder()

                .setSigningKey(KEY)

                .build()

                .parseClaimsJws(token)

                .getBody()

                .getSubject();
    }

    public static boolean validateToken(
            String token
    ) {

        try {

            Jwts.parserBuilder()

                    .setSigningKey(KEY)

                    .build()

                    .parseClaimsJws(token);

            return true;

        }

        catch (Exception e) {

            return false;
        }
    }
}