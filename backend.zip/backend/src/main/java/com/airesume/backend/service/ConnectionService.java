package com.airesume.backend.service;

import com.airesume.backend.dto.ConnectionResponse;
import com.airesume.backend.entity.User;
import com.airesume.backend.exception.ApiException;
import com.airesume.backend.repository.UserRepository;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class ConnectionService {

	private final UserRepository userRepository;

	public ConnectionService(UserRepository userRepository) {
		this.userRepository = userRepository;
	}

	public List<ConnectionResponse> listConnections(String currentEmail) {
		return userRepository.findAll().stream()
				.filter(user -> !user.getEmail().equalsIgnoreCase(currentEmail))
				.map(this::mapToResponse)
				.toList();
	}

	public List<ConnectionResponse> searchConnections(String currentEmail, String query) {
		String lowerQuery = query == null ? "" : query.toLowerCase();
		return listConnections(currentEmail).stream()
				.filter(user -> user.getName().toLowerCase().contains(lowerQuery)
						|| (user.getHeadline() != null && user.getHeadline().toLowerCase().contains(lowerQuery))
						|| user.getEmail().toLowerCase().contains(lowerQuery))
				.toList();
	}

	public Map<String, Object> requestConnection(String currentEmail, String targetEmail) {
		if (targetEmail == null || targetEmail.isBlank()) {
			throw new ApiException(HttpStatus.BAD_REQUEST, "Target email is required");
		}

		if (targetEmail.equalsIgnoreCase(currentEmail)) {
			throw new ApiException(HttpStatus.BAD_REQUEST, "Cannot send connection request to yourself");
		}

		User targetUser = userRepository.findByEmail(targetEmail);
		if (targetUser == null) {
			throw new ApiException(HttpStatus.NOT_FOUND, "User not found");
		}

		User currentUser = userRepository.findByEmail(currentEmail);
		if (currentUser == null) {
			throw new ApiException(HttpStatus.NOT_FOUND, "Current user not found");
		}

		targetUser.setFollowers(targetUser.getFollowers() + 1);
		currentUser.setFollowing(currentUser.getFollowing() + 1);
		targetUser.setConnections(targetUser.getConnections() + 1);
		currentUser.setConnections(currentUser.getConnections() + 1);

		userRepository.save(targetUser);
		userRepository.save(currentUser);

		Map<String, Object> response = new LinkedHashMap<>();
		response.put("message", "Connection request sent successfully");
		response.put("email", targetEmail);
		return response;
	}

	private ConnectionResponse mapToResponse(User user) {
		return new ConnectionResponse(
				user.getName(),
				user.getEmail(),
				user.getHeadline(),
				user.getProfileImage()
		);
	}
}