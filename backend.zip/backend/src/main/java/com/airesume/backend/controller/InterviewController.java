package com.airesume.backend.controller;

import com.airesume.backend.dto.EvaluationResponse;
import com.airesume.backend.dto.EvaluationRequest;
import com.airesume.backend.dto.InterviewRequest;
import com.airesume.backend.service.InterviewService;

import org.springframework.security.core.Authentication;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/interview")
public class InterviewController {

    private final InterviewService interviewService;

    public InterviewController(InterviewService interviewService) {
        this.interviewService = interviewService;
    }

    @PostMapping({"/start", "/questions"})
    public ResponseEntity<List<String>> generateQuestions(
            Authentication authentication,
            @RequestBody InterviewRequest request
    ) {
        return ResponseEntity.ok(
                interviewService.startInterview(
                        authentication.getName(),
                        request
                )
        );
    }

    @PostMapping({"/submit", "/evaluate"})
    public ResponseEntity<EvaluationResponse> evaluateAnswer(
            Authentication authentication,
            @RequestBody EvaluationRequest request
    ) {
        return ResponseEntity.ok(
                interviewService.submitAnswer(
                        authentication.getName(),
                        request
                )
        );
    }
}