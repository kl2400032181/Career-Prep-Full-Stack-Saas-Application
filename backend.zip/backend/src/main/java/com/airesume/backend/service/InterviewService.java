package com.airesume.backend.service;

import com.airesume.backend.dto.EvaluationRequest;
import com.airesume.backend.dto.EvaluationResponse;
import com.airesume.backend.dto.InterviewRequest;
import com.airesume.backend.entity.InterviewHistory;
import com.airesume.backend.entity.User;
import com.airesume.backend.exception.ApiException;
import com.airesume.backend.repository.InterviewHistoryRepository;
import com.airesume.backend.repository.UserRepository;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class InterviewService {

    private final GroqService groqService;
    private final InterviewHistoryRepository interviewHistoryRepository;
    private final UserRepository userRepository;
    private final Map<String, InterviewSession> activeSessions = new ConcurrentHashMap<>();

    public InterviewService(
            GroqService groqService,
            InterviewHistoryRepository interviewHistoryRepository,
            UserRepository userRepository
    ) {
        this.groqService = groqService;
        this.interviewHistoryRepository = interviewHistoryRepository;
        this.userRepository = userRepository;
    }

    public List<String> startInterview(String email, InterviewRequest request) {
        User user = requireUser(email);
        int questionCount = request.getQuestionCount() > 0 ? request.getQuestionCount() : 5;
        String category = request.getCategory() == null ? "React" : request.getCategory();
        String difficulty = request.getDifficulty() == null ? "Easy" : request.getDifficulty();
        String role = request.getRole() == null || request.getRole().isBlank() ? user.getHeadline() : request.getRole();

        List<String> questions = generateQuestions(role, category, difficulty, questionCount);
        activeSessions.put(email, new InterviewSession(role, category, difficulty, questions));
        return questions;
    }

    public EvaluationResponse submitAnswer(String email, EvaluationRequest request) {
        InterviewSession session = activeSessions.get(email);

        if (session == null || session.questions.isEmpty()) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Please start an interview first");
        }

        String question = request.getQuestion();
        if (question == null || question.isBlank()) {
            question = session.currentQuestion();
        }

        EvaluationResponse evaluation = evaluate(question, request.getAnswer(), session);
        session.answers.add(request.getAnswer());
        session.evaluations.add(evaluation);

        if (session.isFinalAnswer()) {
            saveHistory(email, session, question, request.getAnswer(), evaluation);
            activeSessions.remove(email);
        }
        else {
            session.advance();
        }

        return evaluation;
    }

    public List<InterviewHistory> getHistory(String email) {
        return interviewHistoryRepository.findByEmailOrderByCreatedAtDesc(email);
    }

    private List<String> generateQuestions(String role, String category, String difficulty, int questionCount) {
        try {
            String prompt = """
                    Generate %d interview questions as a JSON array of strings only.
                    Role: %s
                    Category: %s
                    Difficulty: %s
                    Keep them professional and unique.
                    """.formatted(questionCount, role, category, difficulty);

            String response = groqService.generateResponse(prompt);
            JSONArray array = new JSONArray(stripCodeFences(response));

            List<String> questions = new ArrayList<>();
            for (int index = 0; index < array.length(); index++) {
                questions.add(array.optString(index));
            }
            if (!questions.isEmpty()) {
                return questions;
            }
        }
        catch (Exception ignored) {
        }

        List<String> fallback = new ArrayList<>();
        for (int index = 1; index <= questionCount; index++) {
            fallback.add("Question " + index + " for " + category + " at " + difficulty + " level for " + role);
        }
        return fallback;
    }

    private EvaluationResponse evaluate(String question, String answer, InterviewSession session) {
        try {
            String prompt = """
                    Evaluate this interview answer and return valid JSON only with keys:
                    technicalScore, communicationScore, confidenceScore, overallScore,
                    strengths, weaknesses, suggestions, summary, feedback.

                    Question: %s
                    Answer: %s
                    Role: %s
                    Category: %s
                    Difficulty: %s
                    """.formatted(question, answer, session.role, session.category, session.difficulty);

            String response = groqService.generateResponse(prompt);
            JSONObject json = new JSONObject(stripCodeFences(response));

            return new EvaluationResponse(
                    json.optInt("technicalScore", 0),
                    json.optInt("communicationScore", 0),
                    json.optInt("confidenceScore", 0),
                    json.optInt("overallScore", 0),
                    parseArray(json.optJSONArray("strengths")),
                    parseArray(json.optJSONArray("weaknesses")),
                    parseArray(json.optJSONArray("suggestions")),
                    json.optString("summary", ""),
                    json.optString("feedback", json.optString("summary", ""))
            );
        }
        catch (Exception exception) {
            return fallbackEvaluation(answer);
        }
    }

    private EvaluationResponse fallbackEvaluation(String answer) {
        int lengthScore = Math.min(40, answer == null ? 0 : answer.length() / 8);
        int communication = answer != null && answer.contains("because") ? 20 : 10;
        int confidence = answer != null && answer.length() > 100 ? 20 : 10;
        int overall = Math.min(100, lengthScore + communication + confidence);
        return new EvaluationResponse(
                Math.min(100, overall),
                communication,
                confidence,
                overall,
                List.of("Clear intent"),
                List.of("Add more concrete examples"),
                List.of("Use STAR format", "Mention measurable outcomes"),
                "Fallback evaluation based on answer length and structure.",
                "Fallback evaluation based on answer length and structure."
        );
    }

    private void saveHistory(String email, InterviewSession session, String question, String answer, EvaluationResponse evaluation) {
        User user = requireUser(email);
        InterviewHistory history = new InterviewHistory();
        history.setEmail(email);
        history.setRole(session.role);
        history.setCategory(session.category);
        history.setDifficulty(session.difficulty);
        history.setQuestion(question);
        history.setAnswer(answer);
        history.setFeedback(evaluation.getFeedback());
        history.setSummary(evaluation.getSummary());
        history.setTechnicalScore(evaluation.getTechnicalScore());
        history.setCommunicationScore(evaluation.getCommunicationScore());
        history.setConfidenceScore(evaluation.getConfidenceScore());
        history.setOverallScore(evaluation.getOverallScore());
        history.setCreatedAt(LocalDateTime.now());
        interviewHistoryRepository.save(history);

        user.setInterviews((int) interviewHistoryRepository.countByEmail(email));
        userRepository.save(user);
    }

    private User requireUser(String email) {
        User user = userRepository.findByEmail(email);
        if (user == null) {
            throw new ApiException(HttpStatus.NOT_FOUND, "User not found");
        }
        return user;
    }

    private List<String> parseArray(JSONArray array) {
        if (array == null) {
            return Collections.emptyList();
        }

        List<String> values = new ArrayList<>();
        for (int index = 0; index < array.length(); index++) {
            values.add(array.optString(index));
        }
        return values;
    }

    private String stripCodeFences(String input) {
        if (input == null) {
            return "{}";
        }
        return input.replace("```json", "").replace("```", "").trim();
    }

    private static class InterviewSession {
        private final String role;
        private final String category;
        private final String difficulty;
        private final List<String> questions;
        private final List<String> answers = new ArrayList<>();
        private final List<EvaluationResponse> evaluations = new ArrayList<>();
        private int index = 0;

        private InterviewSession(String role, String category, String difficulty, List<String> questions) {
            this.role = role;
            this.category = category;
            this.difficulty = difficulty;
            this.questions = questions;
        }

        private String currentQuestion() {
            return questions.get(Math.min(index, questions.size() - 1));
        }

        private boolean isFinalAnswer() {
            return index >= questions.size() - 1;
        }

        private void advance() {
            index++;
        }
    }
}