package com.airesume.backend.dto;

public class EvaluationRequest {

    private String question;

    private String answer;

    public EvaluationRequest() {
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }
}