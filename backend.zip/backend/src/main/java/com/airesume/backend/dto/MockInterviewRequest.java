package com.airesume.backend.dto;

public class MockInterviewRequest {

    private String role;

    private int numberOfQuestions;

    public MockInterviewRequest() {
    }

    public String getRole() {
        return role;
    }

    public int getNumberOfQuestions() {
        return numberOfQuestions;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setNumberOfQuestions(
            int numberOfQuestions
    ) {
        this.numberOfQuestions =
                numberOfQuestions;
    }
}