package com.airesume.backend.service;

import com.airesume.backend.dto.DashboardResponse;
import com.airesume.backend.entity.InterviewHistory;
import com.airesume.backend.entity.ResumeAnalysis;
import com.airesume.backend.entity.User;
import com.airesume.backend.repository.InterviewHistoryRepository;
import com.airesume.backend.repository.ResumeAnalysisRepository;
import com.airesume.backend.repository.UserRepository;

import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

@Service
public class DashboardService {

    private final InterviewHistoryRepository interviewHistoryRepository;
    private final ResumeAnalysisRepository resumeAnalysisRepository;
    private final UserRepository userRepository;

    public DashboardService(
            InterviewHistoryRepository interviewHistoryRepository,
            ResumeAnalysisRepository resumeAnalysisRepository,
            UserRepository userRepository
    ) {
        this.interviewHistoryRepository = interviewHistoryRepository;
        this.resumeAnalysisRepository = resumeAnalysisRepository;
        this.userRepository = userRepository;
    }

    public DashboardResponse getDashboard(String email) {
        List<InterviewHistory> histories = interviewHistoryRepository.findByEmailOrderByCreatedAtDesc(email);
        User user = userRepository.findByEmail(email);
        ResumeAnalysis resumeAnalysis = resumeAnalysisRepository.findTopByEmailOrderByCreatedAtDesc(email).orElse(null);

        DashboardResponse response = new DashboardResponse();
        response.setTotalInterviews(histories.size());
        response.setAverageScore(histories.isEmpty() ? 0 : histories.stream().mapToInt(InterviewHistory::getOverallScore).average().orElse(0));
        response.setBestInterviewScore(histories.stream().mapToInt(InterviewHistory::getOverallScore).max().orElse(0));
        response.setResumeScore(resumeAnalysis != null ? resumeAnalysis.getAtsScore() : (user != null ? user.getResumeScore() : 0));
        response.setAiSuggestion(buildSuggestion(histories, response.getResumeScore()));
        response.setChartData(buildChartData(histories));
        response.setRecentInterviews(buildRecentInterviews(histories));
        response.setActivities(buildActivities(histories));
        return response;
    }

    private List<DashboardResponse.ChartPoint> buildChartData(List<InterviewHistory> histories) {
        List<DashboardResponse.ChartPoint> points = new ArrayList<>();
        List<InterviewHistory> ordered = histories.stream()
                .sorted(Comparator.comparing(InterviewHistory::getCreatedAt))
                .toList();

        int counter = 1;
        for (InterviewHistory history : ordered) {
            points.add(new DashboardResponse.ChartPoint("Interview " + counter++, history.getOverallScore()));
        }

        if (points.isEmpty()) {
            points.add(new DashboardResponse.ChartPoint("Interview 1", 0));
        }

        return points;
    }

    private List<DashboardResponse.RecentInterview> buildRecentInterviews(List<InterviewHistory> histories) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH);
        return histories.stream()
                .limit(5)
                .map(history -> new DashboardResponse.RecentInterview(
                        history.getRole(),
                        history.getOverallScore(),
                        history.getDifficulty(),
                        history.getCreatedAt() != null ? history.getCreatedAt().format(formatter) : "Unknown"
                ))
                .toList();
    }

    private List<DashboardResponse.ActivityItem> buildActivities(List<InterviewHistory> histories) {
        List<DashboardResponse.ActivityItem> activities = new ArrayList<>();

        if (histories.isEmpty()) {
            activities.add(new DashboardResponse.ActivityItem("Profile ready for first interview", "Now"));
            activities.add(new DashboardResponse.ActivityItem("Upload your resume to get ATS insights", "Now"));
            return activities;
        }

        for (InterviewHistory history : histories.stream().limit(5).toList()) {
            activities.add(new DashboardResponse.ActivityItem(
                    "Completed " + history.getRole() + " interview",
                    history.getCreatedAt() != null ? history.getCreatedAt().toString() : "Recently"
            ));
        }

        return activities;
    }

    private String buildSuggestion(List<InterviewHistory> histories, int resumeScore) {
        if (histories.isEmpty()) {
            return "Start your first AI interview to begin building your performance history.";
        }

        double average = histories.stream().mapToInt(InterviewHistory::getOverallScore).average().orElse(0);

        if (average < 60) {
            return "Focus on structured answers, stronger examples, and clearer communication.";
        }

        if (resumeScore < 60) {
            return "Your interview performance is improving. Strengthen your resume to unlock better matches.";
        }

        return "Keep practicing at harder difficulty levels and refine your technical storytelling.";
    }
}