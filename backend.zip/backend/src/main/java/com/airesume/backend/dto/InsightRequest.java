package com.airesume.backend.dto;

public class InsightRequest {

    private String email;

    public InsightRequest() {
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}