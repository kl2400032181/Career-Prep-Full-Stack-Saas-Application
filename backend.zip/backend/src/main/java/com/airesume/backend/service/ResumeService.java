package com.airesume.backend.service;

import com.airesume.backend.dto.ResumeAnalysisResponse;
import com.airesume.backend.entity.ResumeAnalysis;
import com.airesume.backend.entity.User;
import com.airesume.backend.exception.ApiException;
import com.airesume.backend.repository.ResumeAnalysisRepository;
import com.airesume.backend.repository.UserRepository;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

@Service
public class ResumeService {

    private final GroqService groqService;
    private final ResumeAnalyzerService resumeAnalyzerService;
    private final ResumeAnalysisRepository resumeAnalysisRepository;
    private final UserRepository userRepository;

    public ResumeService(
            GroqService groqService,
            ResumeAnalyzerService resumeAnalyzerService,
            ResumeAnalysisRepository resumeAnalysisRepository,
            UserRepository userRepository
    ) {
        this.groqService = groqService;
        this.resumeAnalyzerService = resumeAnalyzerService;
        this.resumeAnalysisRepository = resumeAnalysisRepository;
        this.userRepository = userRepository;
    }

    public ResumeAnalysisResponse analyze(String email, MultipartFile file) {
        if (file == null || file.isEmpty()) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Please upload a resume PDF");
        }

        String extractedText = extractText(file);
        ResumeAnalysisResponse response = buildAnalysis(extractedText);

        ResumeAnalysis analysis = new ResumeAnalysis();
        analysis.setEmail(email);
        analysis.setJobRole(response.getJobRole());
        analysis.setAtsScore(response.getAtsScore());
        analysis.setJobMatch(response.getJobMatch());
        analysis.setStrengthsJson(toJson(response.getStrengths()));
        analysis.setWeaknessesJson(toJson(response.getWeaknesses()));
        analysis.setMissingKeywordsJson(toJson(response.getMissingKeywords()));
        analysis.setSuggestionsJson(toJson(response.getSuggestions()));
        analysis.setSkillsJson(toJson(response.getSkills()));
        analysis.setExtractedText(extractedText);
        resumeAnalysisRepository.save(analysis);

        User user = userRepository.findByEmail(email);
        if (user != null) {
            user.setResumeScore(response.getAtsScore());
            userRepository.save(user);
        }

        return response;
    }

    public ResumeAnalysisResponse getLatest(String email) {
        return resumeAnalysisRepository.findTopByEmailOrderByCreatedAtDesc(email)
                .map(analysis -> new ResumeAnalysisResponse(
                        analysis.getJobRole(),
                        analysis.getAtsScore(),
                        analysis.getJobMatch(),
                        fromJson(analysis.getStrengthsJson()),
                        fromJson(analysis.getWeaknessesJson()),
                        fromJson(analysis.getMissingKeywordsJson()),
                        fromJson(analysis.getSuggestionsJson()),
                        fromJson(analysis.getSkillsJson())
                ))
                .orElseGet(() -> new ResumeAnalysisResponse(
                        "Target Role",
                        0,
                        0,
                        List.of(),
                        List.of(),
                        List.of(),
                        List.of(),
                        List.of()
                ));
    }

    public List<ResumeAnalysisResponse> getHistory(String email) {
        return resumeAnalysisRepository.findByEmailOrderByCreatedAtDesc(email).stream()
                .map(analysis -> new ResumeAnalysisResponse(
                        analysis.getJobRole(),
                        analysis.getAtsScore(),
                        analysis.getJobMatch(),
                        fromJson(analysis.getStrengthsJson()),
                        fromJson(analysis.getWeaknessesJson()),
                        fromJson(analysis.getMissingKeywordsJson()),
                        fromJson(analysis.getSuggestionsJson()),
                        fromJson(analysis.getSkillsJson())
                ))
                .toList();
    }

    private ResumeAnalysisResponse buildAnalysis(String text) {
        try {
            String prompt = """
                    Analyze this resume and return valid JSON only with keys:
                    jobRole, atsScore, jobMatch, strengths, weaknesses, missingKeywords, suggestions, skills.
                    Use arrays of strings for list fields.

                    Resume text:
                    %s
                    """.formatted(text);

            String response = groqService.generateResponse(prompt);
            JSONObject json = new JSONObject(stripCodeFences(response));

            return new ResumeAnalysisResponse(
                    json.optString("jobRole", "Target Role"),
                    json.optInt("atsScore", 0),
                    json.optInt("jobMatch", 0),
                    fromJson(json.optJSONArray("strengths")),
                    fromJson(json.optJSONArray("weaknesses")),
                    fromJson(json.optJSONArray("missingKeywords")),
                    fromJson(json.optJSONArray("suggestions")),
                    fromJson(json.optJSONArray("skills"))
            );
        }

        catch (Exception exception) {
            return fallbackAnalysis(text);
        }
    }

    private ResumeAnalysisResponse fallbackAnalysis(String text) {
        com.airesume.backend.dto.ResumeAnalysisResponse heuristic =
                resumeAnalyzerService.analyzeResume(text);

        return new ResumeAnalysisResponse(
                "Target Role",
                heuristic.getAtsScore(),
                Math.max(heuristic.getAtsScore(), 0),
                heuristic.getStrengths(),
                heuristic.getWeaknesses(),
                heuristic.getMissingKeywords(),
                heuristic.getSuggestions(),
                heuristic.getSkills()
        );
    }

    private String extractText(MultipartFile file) {
        try (PDDocument document = PDDocument.load(file.getInputStream())) {
            PDFTextStripper stripper = new PDFTextStripper();
            return stripper.getText(document);
        }
        catch (IOException exception) {
            throw new ApiException(HttpStatus.BAD_REQUEST, "Unable to read PDF file");
        }
    }

    private List<String> fromJson(JSONArray array) {
        if (array == null) {
            return List.of();
        }

        List<String> items = new ArrayList<>();

        for (int index = 0; index < array.length(); index++) {
            items.add(array.optString(index));
        }

        return items;
    }

    private List<String> fromJson(String json) {
        if (json == null || json.isBlank()) {
            return List.of();
        }

        return fromJson(new JSONArray(json));
    }

    private String toJson(List<String> values) {
        return new JSONArray(values == null ? List.of() : values).toString();
    }

    private String stripCodeFences(String input) {
        if (input == null) {
            return "{}";
        }

        return input.replace("```json", "")
                .replace("```", "")
                .trim();
    }
}