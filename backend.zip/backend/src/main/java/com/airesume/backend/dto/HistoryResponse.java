package com.airesume.backend.dto;

import java.util.List;

public class HistoryResponse {

    private long totalInterviews;
    private double averageScore;
    private int bestScore;
    private List<ChartPoint> chartData;
    private String summary;
    private List<TopicScore> topicPerformance;
    private List<TimelineItem> timeline;
    private List<InterviewItem> interviews;

    public HistoryResponse() {
    }

    public long getTotalInterviews() { return totalInterviews; }
    public double getAverageScore() { return averageScore; }
    public int getBestScore() { return bestScore; }
    public List<ChartPoint> getChartData() { return chartData; }
    public String getSummary() { return summary; }
    public List<TopicScore> getTopicPerformance() { return topicPerformance; }
    public List<TimelineItem> getTimeline() { return timeline; }
    public List<InterviewItem> getInterviews() { return interviews; }

    public void setTotalInterviews(long totalInterviews) { this.totalInterviews = totalInterviews; }
    public void setAverageScore(double averageScore) { this.averageScore = averageScore; }
    public void setBestScore(int bestScore) { this.bestScore = bestScore; }
    public void setChartData(List<ChartPoint> chartData) { this.chartData = chartData; }
    public void setSummary(String summary) { this.summary = summary; }
    public void setTopicPerformance(List<TopicScore> topicPerformance) { this.topicPerformance = topicPerformance; }
    public void setTimeline(List<TimelineItem> timeline) { this.timeline = timeline; }
    public void setInterviews(List<InterviewItem> interviews) { this.interviews = interviews; }

    public static class ChartPoint {
        private String name;
        private int score;

        public ChartPoint() {
        }

        public ChartPoint(String name, int score) {
            this.name = name;
            this.score = score;
        }

        public String getName() { return name; }
        public int getScore() { return score; }
        public void setName(String name) { this.name = name; }
        public void setScore(int score) { this.score = score; }
    }

    public static class TopicScore {
        private String topic;
        private int score;

        public TopicScore() {
        }

        public TopicScore(String topic, int score) {
            this.topic = topic;
            this.score = score;
        }

        public String getTopic() { return topic; }
        public int getScore() { return score; }
        public void setTopic(String topic) { this.topic = topic; }
        public void setScore(int score) { this.score = score; }
    }

    public static class TimelineItem {
        private String role;
        private String date;

        public TimelineItem() {
        }

        public TimelineItem(String role, String date) {
            this.role = role;
            this.date = date;
        }

        public String getRole() { return role; }
        public String getDate() { return date; }
        public void setRole(String role) { this.role = role; }
        public void setDate(String date) { this.date = date; }
    }

    public static class InterviewItem {
        private String role;
        private String category;
        private String difficulty;
        private String date;
        private int score;
        private String feedback;

        public InterviewItem() {
        }

        public InterviewItem(String role, String category, String difficulty, String date, int score, String feedback) {
            this.role = role;
            this.category = category;
            this.difficulty = difficulty;
            this.date = date;
            this.score = score;
            this.feedback = feedback;
        }

        public String getRole() { return role; }
        public String getCategory() { return category; }
        public String getDifficulty() { return difficulty; }
        public String getDate() { return date; }
        public int getScore() { return score; }
        public String getFeedback() { return feedback; }
        public void setRole(String role) { this.role = role; }
        public void setCategory(String category) { this.category = category; }
        public void setDifficulty(String difficulty) { this.difficulty = difficulty; }
        public void setDate(String date) { this.date = date; }
        public void setScore(int score) { this.score = score; }
        public void setFeedback(String feedback) { this.feedback = feedback; }
    }
}