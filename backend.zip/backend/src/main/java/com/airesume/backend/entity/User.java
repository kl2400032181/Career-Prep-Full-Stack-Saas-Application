package com.airesume.backend.entity;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    @Column(unique = true)
    private String email;

    private String password;

    private String role;

    @Column(columnDefinition = "TEXT")
    private String profileImage;

    @Column(columnDefinition = "TEXT")
    private String coverBanner;

    private String headline;

    @Column(columnDefinition = "TEXT")
    private String bio;

    private String location;

    private String college;

    @Column(columnDefinition = "TEXT")
    private String skills;

    @Column(columnDefinition = "TEXT")
    private String experiencesJson;

    @Column(columnDefinition = "TEXT")
    private String projectsJson;

    @Column(columnDefinition = "TEXT")
    private String achievementsJson;

    private String linkedin;

    private String github;

    private String leetcode;

    private String codechef;

    private String portfolio;

    private String careerGoal;

    private long followers;

    private long following;

    private long connections;

    private int profileCompletion;

    private int resumeScore;

    private int interviews;

    private LocalDateTime createdAt;

    private LocalDateTime updatedAt;

    public User() {
    }

    @PrePersist
    public void onCreate() {
        LocalDateTime now = LocalDateTime.now();

        if (createdAt == null) {
            createdAt = now;
        }

        updatedAt = now;

        if (role == null || role.isBlank()) {
            role = "ROLE_USER";
        }

        if (profileCompletion == 0) {
            profileCompletion = 25;
        }
    }

    @PreUpdate
    public void onUpdate() {
        updatedAt = LocalDateTime.now();
    }

    // =========================
    // GETTERS
    // =========================

    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getRole() {
        return role;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public String getCoverBanner() {
        return coverBanner;
    }

    public String getHeadline() {
        return headline;
    }

    public String getBio() {
        return bio;
    }

    public String getLocation() {
        return location;
    }

    public String getCollege() {
        return college;
    }

    public String getSkills() {
        return skills;
    }

    public String getExperiencesJson() {
        return experiencesJson;
    }

    public String getProjectsJson() {
        return projectsJson;
    }

    public String getAchievementsJson() {
        return achievementsJson;
    }

    public String getLinkedin() {
        return linkedin;
    }

    public String getGithub() {
        return github;
    }

    public String getLeetcode() {
        return leetcode;
    }

    public String getCodechef() {
        return codechef;
    }

    public String getPortfolio() {
        return portfolio;
    }

    public String getCareerGoal() {
        return careerGoal;
    }

    public long getFollowers() {
        return followers;
    }

    public long getFollowing() {
        return following;
    }

    public long getConnections() {
        return connections;
    }

    public int getProfileCompletion() {
        return profileCompletion;
    }

    public int getResumeScore() {
        return resumeScore;
    }

    public int getInterviews() {
        return interviews;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    // =========================
    // SETTERS
    // =========================

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    public void setCoverBanner(String coverBanner) {
        this.coverBanner = coverBanner;
    }

    public void setHeadline(String headline) {
        this.headline = headline;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setCollege(String college) {
        this.college = college;
    }

    public void setSkills(String skills) {
        this.skills = skills;
    }

    public void setExperiencesJson(String experiencesJson) {
        this.experiencesJson = experiencesJson;
    }

    public void setProjectsJson(String projectsJson) {
        this.projectsJson = projectsJson;
    }

    public void setAchievementsJson(String achievementsJson) {
        this.achievementsJson = achievementsJson;
    }

    public void setLinkedin(String linkedin) {
        this.linkedin = linkedin;
    }

    public void setGithub(String github) {
        this.github = github;
    }

    public void setLeetcode(String leetcode) {
        this.leetcode = leetcode;
    }

    public void setCodechef(String codechef) {
        this.codechef = codechef;
    }

    public void setPortfolio(String portfolio) {
        this.portfolio = portfolio;
    }

    public void setCareerGoal(String careerGoal) {
        this.careerGoal = careerGoal;
    }

    public void setFollowers(long followers) {
        this.followers = followers;
    }

    public void setFollowing(long following) {
        this.following = following;
    }

    public void setConnections(long connections) {
        this.connections = connections;
    }

    public void setProfileCompletion(int profileCompletion) {
        this.profileCompletion = profileCompletion;
    }

    public void setResumeScore(int resumeScore) {
        this.resumeScore = resumeScore;
    }

    public void setInterviews(int interviews) {
        this.interviews = interviews;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}
    
