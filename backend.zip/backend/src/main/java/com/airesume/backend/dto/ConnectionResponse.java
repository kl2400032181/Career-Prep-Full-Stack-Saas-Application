package com.airesume.backend.dto;

public class ConnectionResponse {

    private String name;

    private String email;

    private String headline;

    private String profileImage;

    public ConnectionResponse() {
    }

    public ConnectionResponse(String name, String email, String headline, String profileImage) {
        this.name = name;
        this.email = email;
        this.headline = headline;
        this.profileImage = profileImage;
    }

    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getHeadline() { return headline; }
    public String getProfileImage() { return profileImage; }

    public void setName(String name) { this.name = name; }
    public void setEmail(String email) { this.email = email; }
    public void setHeadline(String headline) { this.headline = headline; }
    public void setProfileImage(String profileImage) { this.profileImage = profileImage; }
}