package com.airesume.backend.controller;

import com.airesume.backend.dto.ResumeAnalysisResponse;
import com.airesume.backend.service.ResumeService;

import org.springframework.http.ResponseEntity;

import java.util.List;

import org.springframework.http.MediaType;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.security.core.Authentication;

@RestController
@RequestMapping("/api/resume")
public class ResumeController {

    private final ResumeService resumeService;

    public ResumeController(ResumeService resumeService) {
        this.resumeService = resumeService;
    }

    @PostMapping(
            value = {"/analyze", "/upload"},
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE
    )
    public ResponseEntity<ResumeAnalysisResponse> uploadResume(
            Authentication authentication,
            @RequestParam("file")
            MultipartFile file
    ) {
        return ResponseEntity.ok(
                resumeService.analyze(authentication.getName(), file)
        );
    }

    @GetMapping("/latest")
    public ResponseEntity<ResumeAnalysisResponse> getLatestAnalysis(Authentication authentication) {
        return ResponseEntity.ok(
                resumeService.getLatest(authentication.getName())
        );
    }

    @GetMapping("/history")
    public ResponseEntity<List<ResumeAnalysisResponse>> getHistory(Authentication authentication) {
        return ResponseEntity.ok(
                resumeService.getHistory(authentication.getName())
        );
    }
}