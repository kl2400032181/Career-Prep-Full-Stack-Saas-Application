package com.airesume.backend.service;

import com.airesume.backend.dto.HistoryResponse;
import com.airesume.backend.entity.InterviewHistory;
import com.airesume.backend.repository.InterviewHistoryRepository;

import org.springframework.stereotype.Service;

import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@Service
public class HistoryService {

    private final InterviewHistoryRepository interviewHistoryRepository;

    public HistoryService(InterviewHistoryRepository interviewHistoryRepository) {
        this.interviewHistoryRepository = interviewHistoryRepository;
    }

    public HistoryResponse getHistory(String email) {
        List<InterviewHistory> histories = interviewHistoryRepository.findByEmailOrderByCreatedAtDesc(email);
        HistoryResponse response = new HistoryResponse();

        response.setTotalInterviews(histories.size());
        response.setAverageScore(histories.isEmpty() ? 0 : histories.stream().mapToInt(InterviewHistory::getOverallScore).average().orElse(0));
        response.setBestScore(histories.stream().mapToInt(InterviewHistory::getOverallScore).max().orElse(0));
        response.setChartData(buildChartData(histories));
        response.setSummary(buildSummary(histories));
        response.setTopicPerformance(buildTopicPerformance(histories));
        response.setTimeline(buildTimeline(histories));
        response.setInterviews(buildInterviews(histories));
        return response;
    }

    private List<HistoryResponse.ChartPoint> buildChartData(List<InterviewHistory> histories) {
        List<HistoryResponse.ChartPoint> points = new ArrayList<>();
        List<InterviewHistory> ordered = histories.stream()
                .sorted(Comparator.comparing(InterviewHistory::getCreatedAt))
                .toList();

        int counter = 1;
        for (InterviewHistory history : ordered) {
            points.add(new HistoryResponse.ChartPoint("Interview " + counter++, history.getOverallScore()));
        }

        if (points.isEmpty()) {
            points.add(new HistoryResponse.ChartPoint("Interview 1", 0));
        }

        return points;
    }

    private String buildSummary(List<InterviewHistory> histories) {
        if (histories.isEmpty()) {
            return "No interview history yet. Start your first practice session to generate AI insights.";
        }

        double average = histories.stream().mapToInt(InterviewHistory::getOverallScore).average().orElse(0);
        int best = histories.stream().mapToInt(InterviewHistory::getOverallScore).max().orElse(0);
        return "You have completed " + histories.size() + " interviews with an average score of "
                + String.format(Locale.ENGLISH, "%.1f", average)
                + "% and a best score of " + best + "%.";
    }

    private List<HistoryResponse.TopicScore> buildTopicPerformance(List<InterviewHistory> histories) {
        if (histories.isEmpty()) {
            return List.of(new HistoryResponse.TopicScore("General", 0));
        }

        Map<String, List<Integer>> topicScores = new HashMap<>();
        for (InterviewHistory history : histories) {
            String topic = history.getCategory() != null ? history.getCategory() : history.getRole();
            topicScores.computeIfAbsent(topic, key -> new ArrayList<>()).add(history.getOverallScore());
        }

        return topicScores.entrySet().stream()
                .map(entry -> new HistoryResponse.TopicScore(
                        entry.getKey(),
                        (int) Math.round(entry.getValue().stream().mapToInt(Integer::intValue).average().orElse(0))
                ))
                .sorted(Comparator.comparing(HistoryResponse.TopicScore::getScore).reversed())
                .toList();
    }

    private List<HistoryResponse.TimelineItem> buildTimeline(List<InterviewHistory> histories) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy", Locale.ENGLISH);
        return histories.stream()
                .sorted(Comparator.comparing(InterviewHistory::getCreatedAt).reversed())
                .map(history -> new HistoryResponse.TimelineItem(
                        history.getRole(),
                        history.getCreatedAt() != null ? history.getCreatedAt().format(formatter) : "Unknown"
                ))
                .toList();
    }

    private List<HistoryResponse.InterviewItem> buildInterviews(List<InterviewHistory> histories) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd MMM yyyy, hh:mm a", Locale.ENGLISH);
        return histories.stream()
                .map(history -> new HistoryResponse.InterviewItem(
                        history.getRole(),
                        history.getCategory(),
                        history.getDifficulty(),
                        history.getCreatedAt() != null ? history.getCreatedAt().format(formatter) : "Unknown",
                        history.getOverallScore(),
                        history.getFeedback()
                ))
                .toList();
    }
}