package com.airesume.backend.dto;

public class EvaluationResponse {

    private int technicalScore;

    private int communicationScore;

    private int confidenceScore;

    private int overallScore;

    private java.util.List<String> strengths;

    private java.util.List<String> weaknesses;

    private java.util.List<String> suggestions;

    private String summary;

    private String feedback;

    public EvaluationResponse() {
    }

    public EvaluationResponse(
            int technicalScore,
            int communicationScore,
            int confidenceScore,
            int overallScore,
            java.util.List<String> strengths,
            java.util.List<String> weaknesses,
            java.util.List<String> suggestions,
            String summary,
            String feedback
    ) {
        this.technicalScore = technicalScore;
        this.communicationScore = communicationScore;
        this.confidenceScore = confidenceScore;
        this.overallScore = overallScore;
        this.strengths = strengths;
        this.weaknesses = weaknesses;
        this.suggestions = suggestions;
        this.summary = summary;
        this.feedback = feedback;
    }

    public int getTechnicalScore() {
        return technicalScore;
    }

    public int getCommunicationScore() {
        return communicationScore;
    }

    public int getConfidenceScore() {
        return confidenceScore;
    }

    public int getOverallScore() {
        return overallScore;
    }

    public java.util.List<String> getStrengths() {
        return strengths;
    }

    public java.util.List<String> getWeaknesses() {
        return weaknesses;
    }

    public java.util.List<String> getSuggestions() {
        return suggestions;
    }

    public String getSummary() {
        return summary;
    }

    public String getFeedback() {
        return feedback;
    }

    public void setTechnicalScore(int technicalScore) {
        this.technicalScore = technicalScore;
    }

    public void setCommunicationScore(int communicationScore) {
        this.communicationScore = communicationScore;
    }

    public void setConfidenceScore(int confidenceScore) {
        this.confidenceScore = confidenceScore;
    }

    public void setOverallScore(int overallScore) {
        this.overallScore = overallScore;
    }

    public void setStrengths(java.util.List<String> strengths) {
        this.strengths = strengths;
    }

    public void setWeaknesses(java.util.List<String> weaknesses) {
        this.weaknesses = weaknesses;
    }

    public void setSuggestions(java.util.List<String> suggestions) {
        this.suggestions = suggestions;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }
}