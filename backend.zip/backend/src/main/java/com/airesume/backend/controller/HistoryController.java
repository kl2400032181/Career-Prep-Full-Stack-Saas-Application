package com.airesume.backend.controller;

import com.airesume.backend.dto.HistoryResponse;
import com.airesume.backend.service.HistoryService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/history")
public class HistoryController {

	private final HistoryService historyService;

	public HistoryController(HistoryService historyService) {
		this.historyService = historyService;
	}

	@GetMapping
	public ResponseEntity<HistoryResponse> getHistory(Authentication authentication) {
		return ResponseEntity.ok(historyService.getHistory(authentication.getName()));
	}

}
