package com.airesume.backend.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import java.util.List;

@JsonIgnoreProperties(ignoreUnknown = true)
public class ProfileUpdateRequest {

    private String name;
    private String profileImage;
    private String coverBanner;
    private String headline;
    private String bio;
    private String location;
    private String college;
    private String linkedin;
    private String github;
    private String leetcode;
    private String codechef;
    private String portfolio;
    private String careerGoal;
    private List<String> skills;
    private List<ProfileResponse.ExperienceItem> experiences;
    private List<ProfileResponse.ProjectItem> projects;
    private List<String> achievements;
    private long followers;
    private long following;
    private long connections;
    private int profileCompletion;
    private int resumeScore;
    private int interviews;

    public ProfileUpdateRequest() {
    }

    public String getName() { return name; }
    public String getProfileImage() { return profileImage; }
    public String getCoverBanner() { return coverBanner; }
    public String getHeadline() { return headline; }
    public String getBio() { return bio; }
    public String getLocation() { return location; }
    public String getCollege() { return college; }
    public String getLinkedin() { return linkedin; }
    public String getGithub() { return github; }
    public String getLeetcode() { return leetcode; }
    public String getCodechef() { return codechef; }
    public String getPortfolio() { return portfolio; }
    public String getCareerGoal() { return careerGoal; }
    public List<String> getSkills() { return skills; }
    public List<ProfileResponse.ExperienceItem> getExperiences() { return experiences; }
    public List<ProfileResponse.ProjectItem> getProjects() { return projects; }
    public List<String> getAchievements() { return achievements; }
    public long getFollowers() { return followers; }
    public long getFollowing() { return following; }
    public long getConnections() { return connections; }
    public int getProfileCompletion() { return profileCompletion; }
    public int getResumeScore() { return resumeScore; }
    public int getInterviews() { return interviews; }

    public void setName(String name) { this.name = name; }
    public void setProfileImage(String profileImage) { this.profileImage = profileImage; }
    public void setCoverBanner(String coverBanner) { this.coverBanner = coverBanner; }
    public void setHeadline(String headline) { this.headline = headline; }
    public void setBio(String bio) { this.bio = bio; }
    public void setLocation(String location) { this.location = location; }
    public void setCollege(String college) { this.college = college; }
    public void setLinkedin(String linkedin) { this.linkedin = linkedin; }
    public void setGithub(String github) { this.github = github; }
    public void setLeetcode(String leetcode) { this.leetcode = leetcode; }
    public void setCodechef(String codechef) { this.codechef = codechef; }
    public void setPortfolio(String portfolio) { this.portfolio = portfolio; }
    public void setCareerGoal(String careerGoal) { this.careerGoal = careerGoal; }
    public void setSkills(List<String> skills) { this.skills = skills; }
    public void setExperiences(List<ProfileResponse.ExperienceItem> experiences) { this.experiences = experiences; }
    public void setProjects(List<ProfileResponse.ProjectItem> projects) { this.projects = projects; }
    public void setAchievements(List<String> achievements) { this.achievements = achievements; }
    public void setFollowers(long followers) { this.followers = followers; }
    public void setFollowing(long following) { this.following = following; }
    public void setConnections(long connections) { this.connections = connections; }
    public void setProfileCompletion(int profileCompletion) { this.profileCompletion = profileCompletion; }
    public void setResumeScore(int resumeScore) { this.resumeScore = resumeScore; }
    public void setInterviews(int interviews) { this.interviews = interviews; }
}
