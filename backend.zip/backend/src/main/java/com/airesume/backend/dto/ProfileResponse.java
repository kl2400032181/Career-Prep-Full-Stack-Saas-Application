package com.airesume.backend.dto;

import java.util.List;

public class ProfileResponse {

    private String name;

    private String email;

    private String profileImage;

    private String coverBanner;

    private String headline;

    private String bio;

    private String location;

    private String college;

    private List<String> skills;

    private List<ExperienceItem> experiences;

    private List<ProjectItem> projects;

    private List<String> achievements;

    private List<ConnectionResponse> connectionList;

    private String linkedin;

    private String github;

    private String leetcode;

    private String codechef;

    private String portfolio;

    private String careerGoal;

    private long followers;

    private long following;

    private long connections;

    private int profileCompletion;

    private int resumeScore;

    private int interviews;

    public ProfileResponse() {
    }

    // =========================
    // GETTERS
    // =========================

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getProfileImage() {
        return profileImage;
    }

    public String getCoverBanner() {
        return coverBanner;
    }

    public String getHeadline() {
        return headline;
    }

    public String getBio() {
        return bio;
    }

    public String getLocation() {
        return location;
    }

    public String getCollege() {
        return college;
    }

    public List<String> getSkills() {
        return skills;
    }

    public List<ExperienceItem> getExperiences() {
        return experiences;
    }

    public List<ProjectItem> getProjects() {
        return projects;
    }

    public List<String> getAchievements() {
        return achievements;
    }

    public List<ConnectionResponse> getConnectionList() {
        return connectionList;
    }

    public String getLinkedin() {
        return linkedin;
    }

    public String getGithub() {
        return github;
    }

    public String getLeetcode() {
        return leetcode;
    }

    public String getCodechef() {
        return codechef;
    }

    public String getPortfolio() {
        return portfolio;
    }

    public String getCareerGoal() {
        return careerGoal;
    }

    public long getFollowers() {
        return followers;
    }

    public long getFollowing() {
        return following;
    }

    public long getConnections() {
        return connections;
    }

    public int getProfileCompletion() {
        return profileCompletion;
    }

    public int getResumeScore() {
        return resumeScore;
    }

    public int getInterviews() {
        return interviews;
    }

    // =========================
    // SETTERS
    // =========================

    public void setName(String name) {
        this.name = name;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setProfileImage(String profileImage) {
        this.profileImage = profileImage;
    }

    public void setCoverBanner(String coverBanner) {
        this.coverBanner = coverBanner;
    }

    public void setHeadline(String headline) {
        this.headline = headline;
    }

    public void setBio(String bio) {
        this.bio = bio;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setCollege(String college) {
        this.college = college;
    }

    public void setSkills(List<String> skills) {
        this.skills = skills;
    }

    public void setExperiences(List<ExperienceItem> experiences) {
        this.experiences = experiences;
    }

    public void setProjects(List<ProjectItem> projects) {
        this.projects = projects;
    }

    public void setAchievements(List<String> achievements) {
        this.achievements = achievements;
    }

    public void setConnectionList(List<ConnectionResponse> connectionList) {
        this.connectionList = connectionList;
    }

    public void setLinkedin(String linkedin) {
        this.linkedin = linkedin;
    }

    public void setGithub(String github) {
        this.github = github;
    }

    public void setLeetcode(String leetcode) {
        this.leetcode = leetcode;
    }

    public void setCodechef(String codechef) {
        this.codechef = codechef;
    }

    public void setPortfolio(String portfolio) {
        this.portfolio = portfolio;
    }

    public void setCareerGoal(String careerGoal) {
        this.careerGoal = careerGoal;
    }

    public void setFollowers(long followers) {
        this.followers = followers;
    }

    public void setFollowing(long following) {
        this.following = following;
    }

    public void setConnections(long connections) {
        this.connections = connections;
    }

    public void setProfileCompletion(int profileCompletion) {
        this.profileCompletion = profileCompletion;
    }

    public void setResumeScore(int resumeScore) {
        this.resumeScore = resumeScore;
    }

    public void setInterviews(int interviews) {
        this.interviews = interviews;
    }

    public static class ExperienceItem {

        private String role;
        private String company;
        private String duration;
        private String description;

        public ExperienceItem() {
        }

        public ExperienceItem(String role, String company, String duration, String description) {
            this.role = role;
            this.company = company;
            this.duration = duration;
            this.description = description;
        }

        public String getRole() { return role; }
        public String getCompany() { return company; }
        public String getDuration() { return duration; }
        public String getDescription() { return description; }
        public void setRole(String role) { this.role = role; }
        public void setCompany(String company) { this.company = company; }
        public void setDuration(String duration) { this.duration = duration; }
        public void setDescription(String description) { this.description = description; }
    }

    public static class ProjectItem {

        private String title;
        private String description;
        private String github;
        private String live;

        public ProjectItem() {
        }

        public ProjectItem(String title, String description, String github, String live) {
            this.title = title;
            this.description = description;
            this.github = github;
            this.live = live;
        }

        public String getTitle() { return title; }
        public String getDescription() { return description; }
        public String getGithub() { return github; }
        public String getLive() { return live; }
        public void setTitle(String title) { this.title = title; }
        public void setDescription(String description) { this.description = description; }
        public void setGithub(String github) { this.github = github; }
        public void setLive(String live) { this.live = live; }
    }
}