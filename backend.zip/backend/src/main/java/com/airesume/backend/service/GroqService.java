package com.airesume.backend.service;

import org.json.JSONArray;
import org.json.JSONObject;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import org.springframework.web.reactive.function.client.WebClient;

@Service
public class GroqService {

        @Value("${groq.api.key:}")
    private String apiKey;

    private final WebClient webClient =
            WebClient.builder()

                    .baseUrl(
                            "https://api.groq.com/openai/v1"
                    )

                    .build();

    public String generateResponse(
            String prompt
    ) {

        try {

                        if (apiKey == null || apiKey.isBlank()) {
                                throw new IllegalStateException("Groq API key is not configured");
                        }

            JSONArray messages =
                    new JSONArray();

            JSONObject userMessage =
                    new JSONObject();

            userMessage.put(
                    "role",
                    "user"
            );

            userMessage.put(
                    "content",
                    prompt
            );

            messages.put(userMessage);

            JSONObject requestBody =
                    new JSONObject();

            requestBody.put(
                    "model",
                    "llama-3.1-8b-instant"
            );

            requestBody.put(
                    "messages",
                    messages
            );

            requestBody.put(
                    "temperature",
                    0.7
            );

            String response = webClient.post()

                    .uri("/chat/completions")

                    .header(
                            "Authorization",
                            "Bearer " + apiKey
                    )

                    .header(
                            "Content-Type",
                            "application/json"
                    )

                    .bodyValue(
                            requestBody.toString()
                    )

                    .retrieve()

                    .bodyToMono(String.class)

                    .block();

            JSONObject json =
                    new JSONObject(response);

            JSONArray choices =
                    json.getJSONArray(
                            "choices"
                    );

            JSONObject firstChoice =
                    choices.getJSONObject(0);

            JSONObject message =
                    firstChoice.getJSONObject(
                            "message"
                    );

            return message.getString(
                    "content"
            );

        }

        catch (Exception e) {

            e.printStackTrace();

            return "Groq Exception : "
                    + e.getMessage();
        }
    }
}