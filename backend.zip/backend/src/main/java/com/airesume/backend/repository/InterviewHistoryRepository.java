package com.airesume.backend.repository;

import com.airesume.backend.entity.InterviewHistory;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface InterviewHistoryRepository
        extends JpaRepository<InterviewHistory, Long> {

    List<InterviewHistory>
    findByEmailOrderByCreatedAtDesc(
            String email
    );

    List<InterviewHistory>
    findByEmailOrderByOverallScoreDesc(
            String email
    );

    Optional<InterviewHistory>
    findTopByEmailOrderByOverallScoreDesc(
            String email
    );

    long countByEmail(String email);
}