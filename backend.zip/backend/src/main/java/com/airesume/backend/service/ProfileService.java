package com.airesume.backend.service;

import com.airesume.backend.dto.ConnectionResponse;
import com.airesume.backend.dto.ProfileResponse;
import com.airesume.backend.dto.ProfileUpdateRequest;
import com.airesume.backend.entity.User;
import com.airesume.backend.exception.ApiException;
import com.airesume.backend.repository.ResumeAnalysisRepository;
import com.airesume.backend.repository.UserRepository;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

@Service
public class ProfileService {

    private final UserRepository userRepository;
    private final ResumeAnalysisRepository resumeAnalysisRepository;
    private final ObjectMapper objectMapper;

    public ProfileService(
            UserRepository userRepository,
            ResumeAnalysisRepository resumeAnalysisRepository,
            ObjectMapper objectMapper
    ) {
        this.userRepository = userRepository;
        this.resumeAnalysisRepository = resumeAnalysisRepository;
        this.objectMapper = objectMapper;
    }

    public ProfileResponse getProfile(String email) {
        User user = requireUser(email);
        ProfileResponse response = new ProfileResponse();
        populate(response, user);
        return response;
    }

    public ProfileResponse updateProfile(String email, ProfileUpdateRequest request) {
        User user = requireUser(email);

        if (request.getName() != null) user.setName(request.getName());
        if (request.getProfileImage() != null) user.setProfileImage(request.getProfileImage());
        if (request.getCoverBanner() != null) user.setCoverBanner(request.getCoverBanner());
        if (request.getHeadline() != null) user.setHeadline(request.getHeadline());
        if (request.getBio() != null) user.setBio(request.getBio());
        if (request.getLocation() != null) user.setLocation(request.getLocation());
        if (request.getCollege() != null) user.setCollege(request.getCollege());
        if (request.getLinkedin() != null) user.setLinkedin(request.getLinkedin());
        if (request.getGithub() != null) user.setGithub(request.getGithub());
        if (request.getLeetcode() != null) user.setLeetcode(request.getLeetcode());
        if (request.getCodechef() != null) user.setCodechef(request.getCodechef());
        if (request.getPortfolio() != null) user.setPortfolio(request.getPortfolio());
        if (request.getCareerGoal() != null) user.setCareerGoal(request.getCareerGoal());
        if (request.getSkills() != null) user.setSkills(String.join(", ", request.getSkills()));

        if (request.getExperiences() != null) user.setExperiencesJson(toJson(request.getExperiences()));
        if (request.getProjects() != null) user.setProjectsJson(toJson(request.getProjects()));
        if (request.getAchievements() != null) user.setAchievementsJson(toJson(request.getAchievements()));

        user.setProfileCompletion(calculateCompletion(user));

        userRepository.save(user);

        ProfileResponse response = new ProfileResponse();
        populate(response, user);
        return response;
    }

    private void populate(ProfileResponse response, User user) {
        response.setName(user.getName());
        response.setEmail(user.getEmail());
        response.setProfileImage(user.getProfileImage() != null ? user.getProfileImage() : "https://i.pravatar.cc/150");
        response.setCoverBanner(user.getCoverBanner() != null ? user.getCoverBanner() : "");
        response.setHeadline(user.getHeadline() != null ? user.getHeadline() : "Aspiring software engineer");
        response.setBio(user.getBio() != null ? user.getBio() : "Add a short professional bio to highlight your background.");
        response.setLocation(user.getLocation() != null ? user.getLocation() : "Location not set");
        response.setCollege(user.getCollege() != null ? user.getCollege() : "College not set");
        response.setSkills(parseCommaSeparated(user.getSkills()));
        response.setExperiences(fromJson(user.getExperiencesJson(), new TypeReference<List<ProfileResponse.ExperienceItem>>() {}));
        response.setProjects(fromJson(user.getProjectsJson(), new TypeReference<List<ProfileResponse.ProjectItem>>() {}));
        response.setAchievements(fromJson(user.getAchievementsJson(), new TypeReference<List<String>>() {}));
        response.setConnectionList(
            userRepository.findAll().stream()
                .filter(other -> !other.getEmail().equalsIgnoreCase(user.getEmail()))
                .map(other -> new ConnectionResponse(
                    other.getName(),
                    other.getEmail(),
                    other.getHeadline(),
                    other.getProfileImage()
                ))
                .toList()
        );
        response.setLinkedin(user.getLinkedin());
        response.setGithub(user.getGithub());
        response.setLeetcode(user.getLeetcode());
        response.setCodechef(user.getCodechef());
        response.setPortfolio(user.getPortfolio());
        response.setCareerGoal(user.getCareerGoal());
        response.setFollowers(user.getFollowers());
        response.setFollowing(user.getFollowing());
        response.setConnections(user.getConnections());
        response.setProfileCompletion(user.getProfileCompletion());
        response.setResumeScore(user.getResumeScore());
        response.setInterviews(user.getInterviews());
    }

    private int calculateCompletion(User user) {
        int score = 0;
        if (user.getName() != null && !user.getName().isBlank()) score += 15;
        if (user.getHeadline() != null && !user.getHeadline().isBlank()) score += 10;
        if (user.getBio() != null && !user.getBio().isBlank()) score += 10;
        if (user.getLocation() != null && !user.getLocation().isBlank()) score += 5;
        if (user.getCollege() != null && !user.getCollege().isBlank()) score += 10;
        if (user.getSkills() != null && !user.getSkills().isBlank()) score += 10;
        if (user.getLinkedin() != null && !user.getLinkedin().isBlank()) score += 5;
        if (user.getGithub() != null && !user.getGithub().isBlank()) score += 5;
        if (user.getCareerGoal() != null && !user.getCareerGoal().isBlank()) score += 10;
        if (user.getExperiencesJson() != null && !user.getExperiencesJson().isBlank()) score += 5;
        if (user.getProjectsJson() != null && !user.getProjectsJson().isBlank()) score += 5;
        if (user.getAchievementsJson() != null && !user.getAchievementsJson().isBlank()) score += 5;
        return Math.min(100, score);
    }

    private List<String> parseCommaSeparated(String value) {
        if (value == null || value.isBlank()) {
            return new ArrayList<>();
        }
        return Arrays.stream(value.split(","))
                .map(String::trim)
                .filter(item -> !item.isBlank())
                .toList();
    }

    @SuppressWarnings("unchecked")
    private <T> T fromJson(String json, TypeReference<T> typeRef) {
        if (json == null || json.isBlank()) {
            return (T) Collections.emptyList();
        }
        try {
            return objectMapper.readValue(json, typeRef);
        } catch (Exception exception) {
            return (T) Collections.emptyList();
        }
    }

    private String toJson(Object value) {
        if (value == null) {
            return null;
        }
        try {
            return objectMapper.writeValueAsString(value);
        } catch (Exception exception) {
            return null;
        }
    }

    private User requireUser(String email) {
        User user = userRepository.findByEmail(email);
        if (user == null) {
            throw new ApiException(HttpStatus.NOT_FOUND, "User not found");
        }
        return user;
    }

    public User getUser(String email) {
        return requireUser(email);
    }
}
