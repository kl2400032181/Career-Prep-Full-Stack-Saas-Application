package com.airesume.backend.dto;

import java.util.List;

public class ResumeAnalysisResponse {

    private String jobRole;

    private int atsScore;

    private int jobMatch;

    private List<String> strengths;

    private List<String> weaknesses;

    private List<String> missingKeywords;

    private List<String> suggestions;

    private List<String> skills;

    public ResumeAnalysisResponse() {
    }

    public ResumeAnalysisResponse(
            String jobRole,
            int atsScore,
            int jobMatch,
            List<String> strengths,
            List<String> weaknesses,
            List<String> missingKeywords,
            List<String> suggestions,
            List<String> skills
    ) {
        this.jobRole = jobRole;
        this.atsScore = atsScore;
        this.jobMatch = jobMatch;
        this.strengths = strengths;
        this.weaknesses = weaknesses;
        this.missingKeywords = missingKeywords;
        this.suggestions = suggestions;
        this.skills = skills;
    }

    public String getJobRole() {
        return jobRole;
    }

    public int getAtsScore() {
        return atsScore;
    }

    public int getJobMatch() {
        return jobMatch;
    }

    public List<String> getStrengths() {
        return strengths;
    }

    public List<String> getWeaknesses() {
        return weaknesses;
    }

    public List<String> getMissingKeywords() {
        return missingKeywords;
    }

    public List<String> getSuggestions() {
        return suggestions;
    }

    public List<String> getSkills() {
        return skills;
    }

    public void setJobRole(String jobRole) {
        this.jobRole = jobRole;
    }

    public void setAtsScore(int atsScore) {
        this.atsScore = atsScore;
    }

    public void setJobMatch(int jobMatch) {
        this.jobMatch = jobMatch;
    }

    public void setStrengths(List<String> strengths) {
        this.strengths = strengths;
    }

    public void setWeaknesses(List<String> weaknesses) {
        this.weaknesses = weaknesses;
    }

    public void setMissingKeywords(List<String> missingKeywords) {
        this.missingKeywords = missingKeywords;
    }

    public void setSuggestions(List<String> suggestions) {
        this.suggestions = suggestions;
    }

    public void setSkills(List<String> skills) {
        this.skills = skills;
    }
}