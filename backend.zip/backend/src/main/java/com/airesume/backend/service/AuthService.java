package com.airesume.backend.service;

import com.airesume.backend.dto.AuthRequest;
import com.airesume.backend.dto.AuthResponse;
import com.airesume.backend.dto.RegisterRequest;
import com.airesume.backend.entity.User;
import com.airesume.backend.exception.ApiException;
import com.airesume.backend.repository.UserRepository;
import com.airesume.backend.security.JwtUtil;

import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public AuthService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    public AuthResponse register(RegisterRequest request) {
        if (userRepository.findByEmail(request.getEmail()) != null) {
            throw new ApiException(HttpStatus.CONFLICT, "Email already exists");
        }

        User user = new User();
        user.setName(request.getName());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setProfileImage("https://i.pravatar.cc/150");
        user.setCoverBanner("");
        user.setHeadline("Aspiring career candidate");
        user.setBio("Build a professional profile to unlock AI career guidance.");
        user.setLocation("Unknown");
        user.setCollege("Unknown");
        user.setSkills("Java, Spring Boot, React");
        user.setFollowers(0);
        user.setFollowing(0);
        user.setConnections(0);
        user.setResumeScore(0);
        user.setInterviews(0);
        user.setProfileCompletion(25);
        userRepository.save(user);

        String token = JwtUtil.generateToken(user.getEmail());
        return new AuthResponse(token, user.getName(), user.getEmail(), "Registered successfully");
    }

    public AuthResponse login(AuthRequest request) {
        User user = userRepository.findByEmail(request.getEmail());

        if (user == null) {
            throw new ApiException(HttpStatus.NOT_FOUND, "User not found");
        }

        if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
            throw new ApiException(HttpStatus.UNAUTHORIZED, "Invalid password");
        }

        String token = JwtUtil.generateToken(user.getEmail());
        return new AuthResponse(token, user.getName(), user.getEmail(), "Login successful");
    }
}