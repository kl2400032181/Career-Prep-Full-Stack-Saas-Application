package com.airesume.backend.repository;

import com.airesume.backend.entity.ResumeAnalysis;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ResumeAnalysisRepository extends JpaRepository<ResumeAnalysis, Long> {

    Optional<ResumeAnalysis> findTopByEmailOrderByCreatedAtDesc(String email);

    List<ResumeAnalysis> findByEmailOrderByCreatedAtDesc(String email);
}