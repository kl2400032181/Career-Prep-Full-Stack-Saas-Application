package com.airesume.backend.dto;

public class InterviewRequest {

    private String role;

    private String difficulty;

    private int questionCount;

    private String category;

    public InterviewRequest() {
    }

    public String getRole() {
        return role;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public int getQuestionCount() {
        return questionCount;
    }

    public String getCategory() {
        return category;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setDifficulty(String difficulty) {
        this.difficulty = difficulty;
    }

    public void setQuestionCount(int questionCount) {
        this.questionCount = questionCount;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}