package com.airesume.backend.dto;

public class AnalyticsResponse {

    private long totalInterviews;

    private double averageScore;

    private int bestScore;

    public AnalyticsResponse() {
    }

    public AnalyticsResponse(
            long totalInterviews,
            double averageScore,
            int bestScore
    ) {

        this.totalInterviews =
                totalInterviews;

        this.averageScore =
                averageScore;

        this.bestScore =
                bestScore;
    }

    public long getTotalInterviews() {
        return totalInterviews;
    }

    public double getAverageScore() {
        return averageScore;
    }

    public int getBestScore() {
        return bestScore;
    }

    public void setTotalInterviews(
            long totalInterviews
    ) {
        this.totalInterviews =
                totalInterviews;
    }

    public void setAverageScore(
            double averageScore
    ) {
        this.averageScore =
                averageScore;
    }

    public void setBestScore(
            int bestScore
    ) {
        this.bestScore = bestScore;
    }
}