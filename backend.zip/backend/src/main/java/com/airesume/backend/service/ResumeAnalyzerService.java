package com.airesume.backend.service;

import com.airesume.backend.dto.ResumeAnalysisResponse;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ResumeAnalyzerService {

    public ResumeAnalysisResponse analyzeResume(
            String text
    ) {

        int score = 20;

        List<String> strengths = new ArrayList<>();

        List<String> weaknesses = new ArrayList<>();

        List<String> missingKeywords = new ArrayList<>();

        List<String> suggestions =
                new ArrayList<>();

        List<String> skills = new ArrayList<>();

        String lowerText =
                text.toLowerCase();

        // SKILLS CHECK

        if (lowerText.contains("java")) {
            score += 15;
            strengths.add("Java experience highlighted");
            skills.add("Java");
        } else {
            suggestions.add(
                    "Add Java skill"
            );
            missingKeywords.add("Java");
            weaknesses.add("No Java experience detected");
        }

        if (lowerText.contains("spring")) {
            score += 15;
            strengths.add("Spring Boot experience highlighted");
            skills.add("Spring Boot");
        } else {
            suggestions.add(
                    "Add Spring Boot projects"
            );
            missingKeywords.add("Spring Boot");
        }

        if (lowerText.contains("react")) {
            score += 15;
            strengths.add("React experience highlighted");
            skills.add("React");
        } else {
            suggestions.add(
                    "Add React projects"
            );
            missingKeywords.add("React");
        }

        if (lowerText.contains("mysql")) {
            score += 10;
            strengths.add("Database experience highlighted");
            skills.add("MySQL");
        } else {
            suggestions.add(
                    "Add Database skills"
            );
            missingKeywords.add("MySQL");
        }

        if (lowerText.contains("project")) {
            score += 15;
            strengths.add("Projects section included");
        } else {
            suggestions.add(
                    "Add projects section"
            );
            weaknesses.add("Projects section not clearly described");
        }

        if (lowerText.contains("internship")) {
            score += 15;
            strengths.add("Internship experience included");
        } else {
            suggestions.add(
                    "Add internship experience"
            );
            weaknesses.add("No internship experience detected");
        }

        if (lowerText.contains("github")) {
            score += 15;
            strengths.add("GitHub profile included");
        } else {
            suggestions.add(
                    "Add GitHub profile"
            );
            missingKeywords.add("GitHub");
        }

        return new ResumeAnalysisResponse(
                "Target Role",
                Math.min(100, score),
                Math.min(100, score + 5),
                strengths,
                weaknesses,
                missingKeywords,
                suggestions
                , skills
        );
    }
}