package com.airesume.backend.controller;

import com.airesume.backend.dto.ConnectionResponse;
import com.airesume.backend.service.ConnectionService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/connections")
public class ConnectionController {

	private final ConnectionService connectionService;

	public ConnectionController(ConnectionService connectionService) {
		this.connectionService = connectionService;
	}

	@GetMapping
	public ResponseEntity<List<ConnectionResponse>> listConnections(Authentication authentication) {
		return ResponseEntity.ok(connectionService.listConnections(authentication.getName()));
	}

	@GetMapping("/search")
	public ResponseEntity<List<ConnectionResponse>> searchConnections(
			Authentication authentication,
			@RequestParam(defaultValue = "") String query
	) {
		return ResponseEntity.ok(connectionService.searchConnections(authentication.getName(), query));
	}

	@PostMapping("/request")
	public ResponseEntity<Map<String, Object>> requestConnection(
			Authentication authentication,
			@RequestParam String email
	) {
		Map<String, Object> response = connectionService.requestConnection(authentication.getName(), email);
		return ResponseEntity.ok(response);
	}

}
