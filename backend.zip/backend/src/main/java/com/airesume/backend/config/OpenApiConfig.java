package com.airesume.backend.config;

public class OpenApiConfig {

}
