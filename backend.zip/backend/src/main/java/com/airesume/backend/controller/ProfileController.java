package com.airesume.backend.controller;

import com.airesume.backend.dto.ProfileResponse;
import com.airesume.backend.dto.ProfileUpdateRequest;
import com.airesume.backend.service.ProfileService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/profile")
public class ProfileController {

	private final ProfileService profileService;

	public ProfileController(ProfileService profileService) {
		this.profileService = profileService;
	}

	@GetMapping
	public ResponseEntity<ProfileResponse> getProfile(Authentication authentication) {
		return ResponseEntity.ok(profileService.getProfile(authentication.getName()));
	}

	@PutMapping("/update")
	public ResponseEntity<ProfileResponse> updateProfile(
			Authentication authentication,
			@RequestBody ProfileUpdateRequest request
	) {
		return ResponseEntity.ok(profileService.updateProfile(authentication.getName(), request));
	}

	@GetMapping("/{email}")
	public ResponseEntity<ProfileResponse> getProfileByEmail(@PathVariable String email) {
		return ResponseEntity.ok(profileService.getProfile(email));
	}

}
