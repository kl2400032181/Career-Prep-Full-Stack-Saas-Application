package com.airesume.backend.dto;

import java.util.List;

public class DashboardResponse {

    private long totalInterviews;
    private double averageScore;
    private int bestInterviewScore;
    private int resumeScore;
    private String aiSuggestion;
    private List<ChartPoint> chartData;
    private List<RecentInterview> recentInterviews;
    private List<ActivityItem> activities;

    public DashboardResponse() {
    }

    public long getTotalInterviews() { return totalInterviews; }
    public double getAverageScore() { return averageScore; }
    public int getBestInterviewScore() { return bestInterviewScore; }
    public int getResumeScore() { return resumeScore; }
    public String getAiSuggestion() { return aiSuggestion; }
    public List<ChartPoint> getChartData() { return chartData; }
    public List<RecentInterview> getRecentInterviews() { return recentInterviews; }
    public List<ActivityItem> getActivities() { return activities; }

    public void setTotalInterviews(long totalInterviews) { this.totalInterviews = totalInterviews; }
    public void setAverageScore(double averageScore) { this.averageScore = averageScore; }
    public void setBestInterviewScore(int bestInterviewScore) { this.bestInterviewScore = bestInterviewScore; }
    public void setResumeScore(int resumeScore) { this.resumeScore = resumeScore; }
    public void setAiSuggestion(String aiSuggestion) { this.aiSuggestion = aiSuggestion; }
    public void setChartData(List<ChartPoint> chartData) { this.chartData = chartData; }
    public void setRecentInterviews(List<RecentInterview> recentInterviews) { this.recentInterviews = recentInterviews; }
    public void setActivities(List<ActivityItem> activities) { this.activities = activities; }

    public static class ChartPoint {
        private String name;
        private int score;

        public ChartPoint() {
        }

        public ChartPoint(String name, int score) {
            this.name = name;
            this.score = score;
        }

        public String getName() { return name; }
        public int getScore() { return score; }
        public void setName(String name) { this.name = name; }
        public void setScore(int score) { this.score = score; }
    }

    public static class RecentInterview {
        private String role;
        private int score;
        private String difficulty;
        private String date;

        public RecentInterview() {
        }

        public RecentInterview(String role, int score, String difficulty, String date) {
            this.role = role;
            this.score = score;
            this.difficulty = difficulty;
            this.date = date;
        }

        public String getRole() { return role; }
        public int getScore() { return score; }
        public String getDifficulty() { return difficulty; }
        public String getDate() { return date; }
        public void setRole(String role) { this.role = role; }
        public void setScore(int score) { this.score = score; }
        public void setDifficulty(String difficulty) { this.difficulty = difficulty; }
        public void setDate(String date) { this.date = date; }
    }

    public static class ActivityItem {
        private String title;
        private String time;

        public ActivityItem() {
        }

        public ActivityItem(String title, String time) {
            this.title = title;
            this.time = time;
        }

        public String getTitle() { return title; }
        public String getTime() { return time; }
        public void setTitle(String title) { this.title = title; }
        public void setTime(String time) { this.time = time; }
    }
}