package com.airesume.backend.dto;

public class SaveInterviewRequest {

    private String email;

    private String role;

    private String question;

    private String answer;

    private String feedback;

    private int score;

    public SaveInterviewRequest() {
    }

    public String getEmail() {
        return email;
    }

    public String getRole() {
        return role;
    }

    public String getQuestion() {
        return question;
    }

    public String getAnswer() {
        return answer;
    }

    public String getFeedback() {
        return feedback;
    }

    public int getScore() {
        return score;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    public void setScore(int score) {
        this.score = score;
    }
}